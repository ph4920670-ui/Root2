import os
import asyncio
import logging
import sys
import imaplib
import email
import unicodedata
import base64
import io
import random
import time
import aiohttp
from email.header import decode_header
from email.utils import parseaddr, parsedate_to_datetime
from datetime import datetime, timedelta, timezone

# Redireciona stderr → stdout. Discloud só mostra stdout no painel de logs;
# qualquer warning/error que vá pra stderr (asyncio CancelledError, SSL errors,
# tracebacks de exceptions silenciosas do discord.py-self) é INVISÍVEL pro
# admin. Com esse redirect, tudo aparece junto no log. Custo zero, e essencial
# pra diagnosticar crash loops onde a exception some.
sys.stderr = sys.stdout

# Carrega .env manualmente
env_path = os.path.join(os.path.dirname(__file__), '.env')
if os.path.exists(env_path):
    with open(env_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            k, _, v = line.partition('=')
            os.environ.setdefault(k.strip(), v.strip())

import discord

# ═════════════════════════════════════════════════════════════
# Silencia warning de parsing do discord.py-self que aparece em volume
# quando o bot está em servidores grandes. É bug interno da lib:
#
#   THREAD_MEMBERS_UPDATE → _handle_presence_update → Presence._copy →
#   AttributeError: 'FakeClientPresence' object has no attribute 'hidden_activities'
#
# Não afeta nada (mensagens, OCR, PG continuam funcionando) — só polui o log
# do Discloud. Filtramos via logger filter pra não esconder OUTROS warnings
# legítimos do discord.gateway. Solução melhor seria atualizar a lib, mas
# essa versão tá estável com o resto do bot.
# ═════════════════════════════════════════════════════════════
class _FilterFakePresence(logging.Filter):
    def filter(self, record):
        try:
            msg = record.getMessage()
            if 'hidden_activities' in msg or 'FakeClientPresence' in msg:
                return False
            # Cobre o caso em que o erro vem como exception info anexada
            if record.exc_info:
                exc = record.exc_info[1]
                if exc is not None and 'hidden_activities' in str(exc):
                    return False
        except Exception:
            pass
        return True

_gateway_logger = logging.getLogger('discord.gateway')
_gateway_logger.addFilter(_FilterFakePresence())
# state também loga essa exception em casos específicos
logging.getLogger('discord.state').addFilter(_FilterFakePresence())

# Config
CLIENT_ID = os.environ.get('CLIENT_ID', 'sem-id')
DISCORD_TOKEN = os.environ.get('DISCORD_TOKEN', '').strip()
import re

def _parse_ids(raw):
    """Aceita IDs separados por . , ; ou whitespace. Ignora vazios."""
    if not raw:
        return []
    return [p for p in re.split(r'[.,;\s]+', raw) if p.strip()]

GUILD_IDS = _parse_ids(os.environ.get('GUILD_IDS', ''))
FORUM_CHANNEL_IDS = _parse_ids(os.environ.get('FORUM_CHANNEL_IDS', ''))
CATEGORIA_IDS = _parse_ids(os.environ.get('CATEGORIA_ID', ''))
PIX_KEY = os.environ.get('PIX_KEY', '').strip()
MENSAGEM_AUTO = os.environ.get('MENSAGEM_AUTO', '').strip()
IMAGEM_AUTO = os.environ.get('IMAGEM_AUTO', '').strip()
# PIX_AUTO_ATIVO: liga/desliga a resposta automática quando detecta PIX_KEY
# nos canais monitorados. Default = ativo. Valores aceitos: '1', 'true', 'sim',
# 'on', 'ativo' → True. '0', 'false', 'nao', 'off', 'desativado' → False.
# Útil pra cliente pausar o bot temporariamente sem precisar limpar PIX_KEY.
_pix_ativo_raw = (os.environ.get('PIX_AUTO_ATIVO', '1') or '1').strip().lower()
PIX_AUTO_ATIVO = _pix_ativo_raw in ('1', 'true', 'sim', 'on', 'ativo', 'yes', 's')
# MOSTRAR_VALOR_PAGAMENTO: liga/desliga a linha de valor na mensagem de
# pagamento confirmado. Default ligado pra manter comportamento atual.
_mostrar_valor_raw = (os.environ.get('MOSTRAR_VALOR_PAGAMENTO', '1') or '1').strip().lower()
MOSTRAR_VALOR_PAGAMENTO = _mostrar_valor_raw in ('1', 'true', 'sim', 'on', 'ativo', 'yes', 's')

# STILO_CAIXA: estilo visual da caixa de "Pagamento confirmado".
#   - 'pc'         → caixa com bordas ╭─╮ (default, visual atual; bom no PC)
#   - 'mobile_estrela' → caixa com cantos em + e + estrelas, sem ✅/Banco: (compacto, bom no mobile)
#   - 'codeblock'  → mesma caixa de cantos +, porém envolvida em ``` (renderiza
#                    como bloco de código no Discord — fica mais legível no mobile)
#   - 'compacto'   → sem caixa nenhuma, só as linhas (menor possível)
# Default = 'pc' por compat com clientes antigos.
STILO_CAIXA = (os.environ.get('STILO_CAIXA', '') or '').strip().lower()
if STILO_CAIXA not in ('pc', 'mobile_estrela', 'codeblock', 'compacto'):
    STILO_CAIXA = 'pc'
GMAIL_USUARIO = os.environ.get('GMAIL_USUARIO', '').strip()
GMAIL_SENHA_IMAP = os.environ.get('GMAIL_SENHA_IMAP', '').strip()

# Link pra onde mandar o cliente comprar/renovar salas quando o saldo zerar.
# Configurável pelo painel (env var) — NÃO hardcodar. Se vazio, o aviso de
# saldo esgotado sai sem link clicável (só o texto avisando).
LINK_COMPRA_SALA = (os.environ.get('LINK_COMPRA_SALA', '') or '').strip()

# Leitura de comprovantes: usamos Anthropic Claude Haiku.
# A chave é configurada GLOBALMENTE no configurador e chega no bot via
# _fetch_config_configurador (junto com apelidos + salas_key). NÃO vem
# de env var pra o admin gerenciar 1 lugar só. Modelo: claude-haiku-4-5
# (mais barato da Anthropic, multimodal, prompt cacheable).

# Sala — configuração de criação automática
def _int_safe(s, default, lo=None, hi=None):
    """Converte string pra int, com fallback e clamp opcional."""
    try:
        v = int(str(s).strip())
    except (ValueError, TypeError):
        return default
    if lo is not None and v < lo: return lo
    if hi is not None and v > hi: return hi
    return v

MODO_PADRAO = _int_safe(os.environ.get('MODO_PADRAO', ''), 0, 0, 5)  # 0 = não cria sala
SENHA_SALA = (os.environ.get('SENHA_SALA', '') or '').strip()
AUTO_START = _int_safe(os.environ.get('AUTO_START', ''), 0, 0, 8)  # 0 = sem auto-start
SALA_NOME = (os.environ.get('SALA_NOME', '') or '').strip()  # se vazio, usa nome do canal

# FORMATO_SALA: define como o bot envia o ID e a senha após criar a sala.
#   - 'junto'    → 1 mensagem só: "123456789 22"
#   - 'separado' → 2 mensagens: primeira "123456789", segunda "22" (default)
# Default = 'separado' por compatibilidade com clientes antigos que esperavam
# 2 envios. Salvo no painel como string simples.
FORMATO_SALA = (os.environ.get('FORMATO_SALA', '') or '').strip().lower()
if FORMATO_SALA not in ('junto', 'separado'):
    FORMATO_SALA = 'separado'  # default seguro

# Endpoint do configurador (onde o bot busca apelidos + key SalasBot)
CONFIGURADOR_URL = (os.environ.get('CONFIGURADOR_URL', 'https://configadm.discloud.app') or '').rstrip('/')
BOT_FETCH_SECRET = (os.environ.get('BOT_FETCH_SECRET', 'secret-bot-fetch-2026') or '').strip()

# Lista de endpoints da SalasBot, em ordem de preferência. O bot tenta o
# primeiro e, se falhar com erro retryable (BRIDGE_OFFLINE, 5xx, timeout),
# tenta o próximo automaticamente. Configurável via env SALAS_API_URLS
# (vírgula-separado) — útil pra adicionar/remover endpoint sem rebuild.
# Default: as 2 que historicamente funcionam.
_SALAS_API_URLS_ENV = (os.environ.get('SALAS_API_URLS', '') or '').strip()
if _SALAS_API_URLS_ENV:
    SALAS_API_URLS = [u.strip().rstrip('/') for u in _SALAS_API_URLS_ENV.split(',') if u.strip()]
else:
    SALAS_API_URLS = [
        'https://salas-bot.freefireapi.online',
        'https://salasff.com',
    ]
# Mantém SALAS_API_URL como alias da primária — alguns lugares legados podem
# usar e a gente não quer quebrar nada. Sempre = SALAS_API_URLS[0].
SALAS_API_URL = SALAS_API_URLS[0]

# Logging em stdout (pra aparecer nos logs do Discloud)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(message)s',
    datefmt='%H:%M:%S',
    stream=sys.stdout,
)
log = logging.getLogger('selfbot')

def stamp():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

print(f"[{stamp()}] ══════════════════════════════════════════════════════")
print(f"[{stamp()}] 🤖 SELFBOT — Cliente {CLIENT_ID}")
print(f"[{stamp()}] ══════════════════════════════════════════════════════")
print(f"[{stamp()}] DISCORD_TOKEN: {'OK' if DISCORD_TOKEN else '⚠️ NÃO CONFIGURADO'}")
print(f"[{stamp()}] GUILD_IDS    : {len(GUILD_IDS)} ID(s) configurado(s)")
print(f"[{stamp()}] CANAIS       : {len(FORUM_CHANNEL_IDS)} ID(s) configurado(s)")
print(f"[{stamp()}] CATEGORIAS   : {len(CATEGORIA_IDS)} ID(s) configurado(s)" + (f" → {', '.join(CATEGORIA_IDS)}" if CATEGORIA_IDS else ' ⚠️ não configurada'))
print(f"[{stamp()}] GMAIL        : {'OK (' + GMAIL_USUARIO + ')' if GMAIL_USUARIO and GMAIL_SENHA_IMAP else '⚠️ desativado'}")
print(f"[{stamp()}] OCR CLAUDE   : (status carregado quando configurador responder)")
if PIX_KEY and MENSAGEM_AUTO:
    if PIX_AUTO_ATIVO:
        print(f"[{stamp()}] PIX_AUTO     : ✅ MODO SEGURO — MENSAGEM_AUTO sempre responde. PG/GO/comprovantes só após detectar a chave {PIX_KEY[:12]}... no canal.")
    else:
        print(f"[{stamp()}] PIX_AUTO     : ⏸️ MODO LEGADO — MENSAGEM_AUTO sempre responde. PG/GO/comprovantes ativos em todos os canais monitorados imediatamente.")
else:
    print(f"[{stamp()}] PIX_AUTO     : ⚠️ MENSAGEM_AUTO desativada (precisa PIX_KEY + MENSAGEM_AUTO configurados)")
if MODO_PADRAO > 0:
    auto_str = f"auto-start {AUTO_START}min" if AUTO_START > 0 else "sem auto-start"
    senha_str = f"senha '{SENHA_SALA}'" if SENHA_SALA else "sem senha"
    nome_str = f"nome '{SALA_NOME}'" if SALA_NOME else "nome=canal"
    fmt_str = f"formato={FORMATO_SALA}"
    print(f"[{stamp()}] SALA_AUTO    : OK (modo padrão {MODO_PADRAO}, {nome_str}, {senha_str}, {auto_str}, {fmt_str})")
else:
    print(f"[{stamp()}] SALA_AUTO    : ⚠️ desativada (MODO_PADRAO=0). Bot vai só mandar MENSAGEM_AUTO no PIX.")
print(f"[{stamp()}] CONFIG_URL   : {CONFIGURADOR_URL}")
if IMAGEM_AUTO:
    tipo_img = 'data URL' if IMAGEM_AUTO.startswith('data:') else 'URL externa' if IMAGEM_AUTO.startswith('http') else 'inválida'
    print(f"[{stamp()}] IMG_AUTO     : OK ({tipo_img})")
else:
    print(f"[{stamp()}] IMG_AUTO     : (vazio — só texto)")
if LINK_COMPRA_SALA:
    print(f"[{stamp()}] COMPRA_SALA  : OK (link configurado)")
else:
    print(f"[{stamp()}] COMPRA_SALA  : ⚠️ sem link (aviso de saldo sai sem botão de compra)")
print(f"[{stamp()}] ══════════════════════════════════════════════════════", flush=True)

if not DISCORD_TOKEN:
    print(f"[{stamp()}] ⏸️ Sem DISCORD_TOKEN — aguardando configuração. Bot ficará idle.", flush=True)
    import time
    i = 0
    while True:
        i += 1
        print(f"[{stamp()}] Cliente {CLIENT_ID} idle. Ciclo #{i}", flush=True)
        time.sleep(60)

# ════════ Selfbot (discord.py-self) ════════
# Selfbots usam token de usuário e NÃO precisam de intents — a conta
# já tem acesso natural ao que enxerga no app. Passar intents quebra.
client = discord.Client()

@client.event
async def on_ready():
    print(f"[{stamp()}] ✅ BOT CONECTADO")
    print(f"[{stamp()}] 👤 Usuário: {client.user} (ID: {client.user.id})")
    print(f"[{stamp()}] 🏠 Servidores conectados: {len(client.guilds)}", flush=True)

    # Lista servidores
    print(f"[{stamp()}] ────────────────────────────────────────")
    for g in client.guilds:
        marker = '✅ MONITORANDO' if str(g.id) in GUILD_IDS else '⏭️  IGNORADO  '
        print(f"[{stamp()}] {marker} → {g.name} (ID: {g.id})")
    print(f"[{stamp()}] ────────────────────────────────────────", flush=True)

    # Inicia loop de fetch de config (apelidos + key SalasBot + key Anthropic) do configurador
    client.loop.create_task(fetch_config_loop())

    # Scan ÚNICO no startup — só lista o que está configurado pra ajudar diagnóstico.
    # NÃO roda em loop pra não martelar a Discord API (selfbot pode ser banido).
    # O bot funciona reativamente via on_message — não precisa varrer periodicamente.
    client.loop.create_task(scan_canais())

# O scan antigo rodava num loop a cada 60s lendo histórico de cada canal de cada
# categoria configurada — isso facilmente passava de 300 requests/min e detonava o
# rate limit do Discord pra conta de usuário (selfbot). Removido completamente.

async def scan_canais():
    """Diagnóstico UMA VEZ no startup. Lista canais configurados e — só nos que
    o bot tem permissão de LEITURA — lê últimas mensagens com sleep entre requests
    pra não bater no rate limit.

    Sem permissão é filtrado VIA CACHE (sem HTTP) usando channel.permissions_for(me),
    que calcula a partir dos overrides já recebidos via gateway. Assim a gente
    NÃO faz request HTTP só pra descobrir que o canal é Forbidden.

    Em uma conta com 305 canais filhos mas só ~10 acessíveis, fazemos 10 requests
    com 0.5s de intervalo = ~5s no scan inteiro. Antes eram 300+ requests gerando
    rate limit em massa.

    Override via env var: SCAN_LER_MSGS=0 desativa leitura de mensagens (só lista
    nomes via cache). Útil se quiser zero risco de rate limit no startup.
    """
    SCAN_LER_MSGS = (os.environ.get('SCAN_LER_MSGS', '1') or '1').strip() != '0'

    # Junta FORUM_CHANNEL_IDS + CATEGORIA_IDS, sem duplicar
    ids_para_varrer = list(FORUM_CHANNEL_IDS)
    for cat in CATEGORIA_IDS:
        if cat not in ids_para_varrer:
            ids_para_varrer.append(cat)

    if not ids_para_varrer:
        print(f"[{stamp()}] [SCAN] ⚠️ Nenhum canal/categoria configurado para monitorar.", flush=True)
        return

    modo = "lendo msgs nos canais com permissão" if SCAN_LER_MSGS else "só listando nomes (SCAN_LER_MSGS=0)"
    print(f"[{stamp()}] [SCAN] 🔍 Iniciando varredura ({modo})...", flush=True)
    total_topicos = 0
    total_canais_categoria = 0
    total_msgs_lidas = 0
    total_lidos = 0   # canais que retornaram OK ao ler msgs
    total_pulados = 0  # canais sem permissão (filtrados via cache)

    # Helper interno: testa permissão de leitura via CACHE (sem HTTP)
    def _pode_ler(canal):
        try:
            me = canal.guild.me if hasattr(canal, 'guild') and canal.guild else None
            if not me:
                return False
            perms = canal.permissions_for(me)
            # Pra ler histórico precisa de view_channel + read_message_history
            return bool(perms.view_channel and perms.read_message_history)
        except Exception:
            return False

    # Helper: lê msgs com tratamento e sleep
    async def _ler_seguro(canal, limite=5, sleep_apos=0.5):
        nonlocal total_msgs_lidas, total_lidos, total_pulados
        if not _pode_ler(canal):
            total_pulados += 1
            return None  # sem permissão (cache) — não tenta HTTP
        try:
            msgs = []
            async for m in canal.history(limit=limite):
                msgs.append(m)
            total_msgs_lidas += len(msgs)
            total_lidos += 1
            # Sleep humano entre requests pra não acumular rate limit. Discord
            # aceita até 50 req/s por bot, mas selfbot tem limites mais agressivos.
            # 0.5s entre canais = 2 req/s, muito tranquilo.
            await asyncio.sleep(sleep_apos)
            return msgs
        except discord.Forbidden:
            # Cache estava desatualizado — permissão mudou. Conta como pulado.
            total_pulados += 1
            return None
        except Exception as e:
            print(f"[{stamp()}] [SCAN]    ⚠️ erro lendo #{getattr(canal, 'name', '?')}: {e}")
            return None

    for ch_id in ids_para_varrer:
        try:
            ch = client.get_channel(int(ch_id))
            if not ch:
                print(f"[{stamp()}] [SCAN] ⚠️ ID {ch_id} não encontrado no cache (sem acesso ou inválido).")
                continue

            ch_name = getattr(ch, 'name', 'sem-nome')
            guild_name = ch.guild.name if hasattr(ch, 'guild') and ch.guild else '?'

            # FÓRUM: lista tópicos + lê msgs de cada (com permissão)
            if isinstance(ch, discord.ForumChannel):
                topicos = list(ch.threads)
                total_topicos += len(topicos)
                print(f"[{stamp()}] [SCAN] 📋 {guild_name} ▸ fórum #{ch_name}: {len(topicos)} tópico(s) ativo(s)")
                if SCAN_LER_MSGS:
                    for t in topicos:
                        msgs = await _ler_seguro(t, limite=5)
                        if msgs is None:
                            continue
                        print(f"[{stamp()}]    ├─ 🧵 {t.name}: {len(msgs)} msg(s)")
                        for m in msgs[:3]:
                            autor = m.author.name if m.author else '?'
                            conteudo = (m.content or '').replace('\n', ' ')[:60]
                            print(f"[{stamp()}]    │  └─ 📌 {autor}: {conteudo}")
                else:
                    for t in topicos[:5]:
                        print(f"[{stamp()}]    ├─ 🧵 {t.name}")
                    if len(topicos) > 5:
                        print(f"[{stamp()}]    └─ ... e mais {len(topicos) - 5}")

            # CATEGORIA: filtra filhos POR PERMISSÃO (cache) e lê só os com acesso
            elif isinstance(ch, discord.CategoryChannel):
                filhos = list(ch.text_channels)
                total_canais_categoria += len(filhos)

                if SCAN_LER_MSGS:
                    # Filtra ANTES via cache, sem HTTP
                    com_perm = [f for f in filhos if _pode_ler(f)]
                    sem_perm = len(filhos) - len(com_perm)
                    extra = f" ({sem_perm} sem permissão — filtrados via cache)" if sem_perm else ""
                    print(f"[{stamp()}] [SCAN] 📁 {guild_name} ▸ categoria #{ch_name}: {len(filhos)} canal(is), {len(com_perm)} com permissão{extra}")

                    # Lê msgs só dos que têm permissão
                    for sub in com_perm:
                        msgs = await _ler_seguro(sub, limite=5)
                        if msgs is None:
                            continue
                        print(f"[{stamp()}]    ├─ 💬 #{sub.name}: {len(msgs)} msg(s)")
                        for m in msgs[:3]:
                            autor = m.author.name if m.author else '?'
                            conteudo = (m.content or '').replace('\n', ' ')[:60]
                            print(f"[{stamp()}]    │  └─ 📌 {autor}: {conteudo}")
                else:
                    # Modo leve — só lista nomes (sem HTTP)
                    print(f"[{stamp()}] [SCAN] 📁 {guild_name} ▸ categoria #{ch_name}: {len(filhos)} canal(is) de texto")
                    for sub in filhos[:8]:
                        print(f"[{stamp()}]    ├─ 💬 #{sub.name}")
                    if len(filhos) > 8:
                        print(f"[{stamp()}]    └─ ... e mais {len(filhos) - 8}")

            # CANAL DE TEXTO normal
            else:
                tipo = type(ch).__name__
                if SCAN_LER_MSGS:
                    msgs = await _ler_seguro(ch, limite=10)
                    if msgs is None:
                        print(f"[{stamp()}] [SCAN] 💬 {guild_name} #{ch_name} ({tipo}): sem permissão de leitura")
                    else:
                        print(f"[{stamp()}] [SCAN] 💬 {guild_name} #{ch_name} ({tipo}): {len(msgs)} msg(s)")
                        for m in msgs[:5]:
                            autor = m.author.name if m.author else '?'
                            conteudo = (m.content or '').replace('\n', ' ')[:60]
                            print(f"[{stamp()}]    └─ 📌 {autor}: {conteudo}")
                else:
                    print(f"[{stamp()}] [SCAN] 💬 {guild_name} #{ch_name} ({tipo})")

        except Exception as e:
            print(f"[{stamp()}] [SCAN] erro no ID {ch_id}: {e}")

    resumo = "📦 Scan completo"
    if SCAN_LER_MSGS:
        resumo += f" — {total_lidos} canal(is) lido(s) ({total_msgs_lidas} msg), {total_pulados} pulado(s) sem permissão"
    if total_topicos:
        resumo += f", {total_topicos} tópico(s)"
    if total_canais_categoria:
        resumo += f", {total_canais_categoria} canal(is) em categorias"
    resumo += ". Bot reagirá via on_message daqui em diante."
    print(f"[{stamp()}] [SCAN] {resumo}", flush=True)


# _ler_msgs ficou órfão — não é mais usado. Mantenho a definição comentada
# pra referência, caso queira fazer scan manual no futuro.
async def _ler_msgs(canal, limite):
    """[DEPRECATED — não chamar mais] Lê até `limite` mensagens recentes via HTTP.
    Era chamada a cada 60s no scan_loop antigo, causando rate limit 429 em massa
    e risco de ban da conta de usuário. Não use periodicamente."""
    msgs = []
    async for m in canal.history(limit=limite):
        msgs.append(m)
    return msgs


# ═════════════════════════════════════════════════════════════
# Comando `pg <nome> <sobrenome>` → busca no IMAP do Gmail
# ═════════════════════════════════════════════════════════════
def _norm(s):
    """Lowercase + remove acentos. 'João' → 'joao'."""
    if not s:
        return ''
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(c for c in s if not unicodedata.combining(c))
    return s.lower().strip()


def _decode_mime(s):
    """Decodifica header MIME tipo '=?utf-8?b?...?=' pra texto legível."""
    if not s:
        return ''
    try:
        partes = decode_header(s)
        out = []
        for txt, enc in partes:
            if isinstance(txt, bytes):
                try:
                    out.append(txt.decode(enc or 'utf-8', errors='replace'))
                except Exception:
                    out.append(txt.decode('utf-8', errors='replace'))
            else:
                out.append(txt)
        return ''.join(out)
    except Exception:
        return str(s)


def _conectar_imap():
    """Conecta no Gmail IMAP e retorna o objeto m logado e com INBOX selecionado.
    Levanta exceção se falhar. Caller é responsável por chamar m.logout()."""
    if not GMAIL_USUARIO or not GMAIL_SENHA_IMAP:
        raise RuntimeError('Gmail não configurado')
    m = imaplib.IMAP4_SSL('imap.gmail.com', 993)
    m.login(GMAIL_USUARIO, GMAIL_SENHA_IMAP)
    m.select('INBOX', readonly=True)
    return m


# Domínios oficiais dos bancos. Compartilhado entre buscar_emails_em_conexao
# e qualquer outra função que precise reconhecer o remetente.
_BANCOS = {
    'nubank.com.br': 'Nubank',
    'nu.com.br':     'Nubank',
    'bancointer.com.br': 'Inter',
    'inter.co':          'Inter',
    'picpay.com':    'PicPay',
    'picpay.com.br': 'PicPay',
}

# Regex pra achar valor R$ X,XX no texto do email
_RE_VALOR_EMAIL = re.compile(r'R\$\s*(\d{1,6}(?:[.,]\d{3})*[.,]\d{2})')


def _banco_do_endereco(addr):
    if not addr or '@' not in addr:
        return None
    dom = addr.split('@', 1)[1].lower().strip()
    for d, nome in _BANCOS.items():
        if dom == d or dom.endswith('.' + d):
            return nome
    return None


# ─── Extração do nome do PAGADOR a partir do CORPO do email ───
# O header `From:` do email é o endereço do BANCO (todomundo@nubank.com.br),
# nunca o nome de quem pagou. O nome real do pagador está no corpo/assunto da
# notificação PIX. Cada banco escreve de um jeito; cobrimos os padrões mais
# comuns com regex. Se nenhum bater, retornamos '' e o caller usa fallback.
#
# Exemplos de frases reais nas notificações:
#   Nubank : "Você recebeu uma transferência de R$ X de FULANO DE TAL"
#            "FULANO DE TAL te enviou R$ X"
#   Inter  : "Você recebeu um Pix de FULANO DE TAL"
#   PicPay : "FULANO DE TAL pagou você" / "Você recebeu de FULANO DE TAL"
# O nome costuma vir em CAIXA ALTA ou Capitalizado, 2 a 6 palavras.
_RE_NOME_PAGADOR = [
    # "recebeu ... de [R$ X] NOME" — pula um eventual "R$ valor" entre o "de"
    # e o nome. Cobre Nubank/Inter: "recebeu uma transferência de R$ 1,35 de FULANO".
    re.compile(
        r'receb(?:eu|ido)\s+(?:uma?\s+)?(?:transfer[êe]ncia|pix|pagamento|dinheiro)?\s*'
        r'(?:de|do|da)\s+(?:r\$\s*[\d.,]+\s+(?:de\s+)?)?'
        r'([A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+(?:\s+[A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+){1,4})',
        re.IGNORECASE),
    # "transferência/pix de [R$ X] NOME" — variante sem o "recebeu" antes.
    re.compile(
        r'(?:transfer[êe]ncia|pix|pagamento)\s+de\s+(?:r\$\s*[\d.,]+\s+(?:de\s+)?)?'
        r'([A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+(?:\s+[A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+){1,4})',
        re.IGNORECASE),
    # "NOME te enviou" / "NOME pagou você" / "NOME transferiu" / "NOME enviou R$"
    # — o verbo fica FORA do grupo capturado, então o nome não engole a palavra-verbo.
    re.compile(
        r'\b([A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+(?:\s+[A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+){1,4})\s+'
        r'(?:te\s+enviou|enviou|pagou|transferiu)\b',
        re.IGNORECASE),
    # "De: NOME" / "Pagador: NOME" / "Remetente: NOME" — formato chave-valor
    # que aparece em alguns emails do Inter, Itaú, Bradesco e PicPay.
    re.compile(
        r'(?:^|\n|\s)(?:de|pagador|remetente|origem|pagou)\s*[:\-]\s*'
        r'([A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+(?:\s+[A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+){1,4})',
        re.IGNORECASE),
    # "Pix recebido de NOME" / "Pix de NOME R$" — variante curta do Inter.
    re.compile(
        r'pix\s+(?:recebido\s+)?de\s+'
        r'([A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+(?:\s+[A-ZÀ-Ýa-zà-ÿ][\wÀ-ÿ]+){1,4})',
        re.IGNORECASE),
]

# Palavras que NUNCA são nome de pessoa — se o regex pegar uma dessas, descarta.
_NAO_EH_NOME = {
    'voce', 'você', 'pix', 'banco', 'nubank', 'inter', 'picpay', 'conta',
    'transferencia', 'transferência', 'pagamento', 'recebido', 'recebeu',
    'reais', 'real', 'dinheiro', 'valor', 'cliente', 'aviso', 'notificacao',
}

# Palavras de "cauda" — se aparecerem no FIM do nome capturado, são aparadas.
# Cobre "Maria Santos no valor" → "Maria Santos", "Joao Silva pelo Pix" → "Joao Silva".
_CAUDA_NAO_NOME = {
    'no', 'na', 'nos', 'nas', 'pelo', 'pela', 'via', 'com', 'em', 'para',
    'pra', 'que', 'foi', 'te', 'voce', 'você', 'agora', 'hoje', 'enviou',
    'pagou', 'transferiu', 'valor', 'reais', 'pix',
}


def _extrair_nome_pagador(texto_completo, assunto=''):
    """Tenta extrair o nome de quem PAGOU a partir do texto do email do banco.

    Recebe o texto completo (assunto + corpo). Roda os regexes de `_RE_NOME_PAGADOR`
    e devolve o primeiro nome plausível encontrado, já capitalizado bonito
    ('JOAO DA SILVA' → 'Joao Da Silva'). Retorna '' se não achar nada confiável.

    Filtros de sanidade:
      - apara palavras de cauda que não são nome (no, pelo, via...)
      - nome precisa ter 2 a 6 palavras depois da poda
      - nenhuma palavra pode ser uma stopword bancária (_NAO_EH_NOME)
      - cada palavra precisa ter 2+ letras
    """
    fontes = [assunto or '', texto_completo or '']
    for fonte in fontes:
        if not fonte:
            continue
        for rgx in _RE_NOME_PAGADOR:
            for m in rgx.finditer(fonte):
                bruto = (m.group(1) or '').strip()
                if not bruto:
                    continue
                palavras = [p for p in bruto.split() if p.strip()]
                # Apara palavras de cauda que claramente não são nome
                while palavras and _norm(palavras[-1]) in _CAUDA_NAO_NOME:
                    palavras.pop()
                if not (2 <= len(palavras) <= 6):
                    continue
                # Rejeita se alguma palavra é stopword ou curta demais
                ruim = False
                for p in palavras:
                    pl = _norm(p)
                    if pl in _NAO_EH_NOME or len(pl) < 2:
                        ruim = True
                        break
                if ruim:
                    continue
                # Capitaliza: 'JOAO DA SILVA' / 'joao da silva' → 'Joao Da Silva'
                return ' '.join(p.capitalize() for p in palavras)
    return ''


def buscar_emails_em_conexao(m, termos_norm, max_emails_recentes=50, minutos_janela=2):
    """Versão otimizada: reutiliza uma conexão IMAP já aberta.
    Busca emails dos bancos dos últimos `minutos_janela` minutos.

    Parâmetros:
      m: conexão IMAP4_SSL já logada com INBOX selecionado.
      termos_norm: tupla (palavras_nome, valor_minimo).
      max_emails_recentes: limite de safety pra não baixar lixo se houver
        muitos emails na janela (raro).
      minutos_janela: só considera emails recebidos nos últimos X minutos.
        Default 2min — alinha com a janela do pgmto (cliente paga, posta pg em segundos).

    Retorna lista de dicts: [{remetente, endereco, assunto, data, banco, valor}].
    """
    palavras_nome, valor_minimo = termos_norm

    # Filtra direto no servidor por remetentes dos 3 bancos + janela de tempo.
    # SINCE no IMAP só aceita data (não hora), então usa ontem e filtra hora em Python.
    criterios = [f'FROM "{d}"' for d in _BANCOS]

    # IMAP OR só aceita 2 argumentos por vez; encadeia
    def encadeia_or(crits):
        if len(crits) == 1:
            return crits[0]
        return f'OR {crits[0]} ({encadeia_or(crits[1:])})'
    criterio_bancos = encadeia_or(criterios)

    # Pra cobrir virada de meia-noite, busca desde ONTEM (filtro fino no Python)
    ontem = (datetime.now(timezone.utc) - timedelta(days=1)).strftime('%d-%b-%Y')
    criterio = f'(SINCE {ontem}) ({criterio_bancos})'

    typ, data = m.uid('search', None, criterio)
    if typ != 'OK':
        return []
    uids = data[0].split()
    if not uids:
        return []
    # Mais recente primeiro, só os N últimos
    uids = uids[::-1][:max_emails_recentes]

    # Corte temporal — só aceita emails recebidos nos últimos `minutos_janela` minutos
    corte = datetime.now(timezone.utc) - timedelta(minutes=minutos_janela)

    encontrados = []
    for uid in uids:
        typ, msg_data = m.uid('fetch', uid, '(BODY.PEEK[])')
        if typ != 'OK' or not msg_data or not msg_data[0]:
            continue
        raw = msg_data[0][1]
        if not isinstance(raw, (bytes, bytearray)):
            continue

        try:
            msg = email.message_from_bytes(raw)
        except Exception:
            continue

        # Filtro de tempo: descarta se mais antigo que `minutos_janela` minutos.
        # Como a lista vem mais nova → mais velha, se passar do corte, todas
        # as próximas também passaram — para.
        data_raw = msg.get('Date', '')
        try:
            dt = parsedate_to_datetime(data_raw)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            if dt < corte:
                break
        except Exception:
            # Se não conseguiu parsear a data, ignora o email pra não correr
            # o risco de aceitar um email antigo
            continue

        from_raw = _decode_mime(msg.get('From', ''))
        _disp, addr = parseaddr(from_raw)
        banco = _banco_do_endereco(addr)
        if not banco:
            continue

        assunto = _decode_mime(msg.get('Subject', '(sem assunto)'))

        # Extrai corpo (texto puro) — emails de banco às vezes só têm HTML
        corpo = ''
        try:
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == 'text/plain':
                        payload = part.get_payload(decode=True) or b''
                        charset = part.get_content_charset() or 'utf-8'
                        corpo = payload.decode(charset, errors='replace')
                        break
                if not corpo:
                    for part in msg.walk():
                        if part.get_content_type() == 'text/html':
                            payload = part.get_payload(decode=True) or b''
                            charset = part.get_content_charset() or 'utf-8'
                            html = payload.decode(charset, errors='replace')
                            corpo = re.sub(r'<[^>]+>', ' ', html)
                            corpo = re.sub(r'\s+', ' ', corpo)
                            break
            else:
                payload = msg.get_payload(decode=True) or b''
                charset = msg.get_content_charset() or 'utf-8'
                corpo = payload.decode(charset, errors='replace')
                if '<' in corpo and '>' in corpo:
                    corpo = re.sub(r'<[^>]+>', ' ', corpo)
                    corpo = re.sub(r'\s+', ' ', corpo)
        except Exception:
            corpo = ''

        texto_completo = (assunto + ' \n ' + corpo)
        texto_norm = _norm(texto_completo)

        # Match nome: aceita match PARCIAL com duas regras (qualquer uma serve):
        #   (1) MÍNIMO 2 das palavras DIGITADAS (ignorando stopwords) aparecem no email
        #       — pega casos como cliente digita 'pg yasmin de sousa' mas o email só
        #       tem 'Yasmin Sousa' (sem o "de"). 2/2 nomes reais já basta.
        #   (2) PRIMEIRO + ÚLTIMO nome digitados (já filtrados de stopword) aparecem
        #       ambos — robusto se cliente esquecer palavras do meio.
        # IMPORTANTE: stopwords como 'de', 'da', 'do' são ignoradas pra evitar falso
        # positivo. Se cliente digita 'yasmin de sousa' e o email é 'Carlos Sousa',
        # a palavra 'de' aparece (preposição) mas isso NÃO conta como match. Só
        # 'yasmin'+'sousa' (nomes reais) é que contam, e como 'yasmin' não bate,
        # email rejeitado corretamente.
        STOPWORDS_NOME = {'de', 'da', 'do', 'dos', 'das', 'e'}
        palavras_reais = [p for p in palavras_nome if p not in STOPWORDS_NOME]

        if len(palavras_reais) >= 2:
            matches = sum(1 for p in palavras_reais if p in texto_norm)
            regra1_ok = matches >= 2
            regra2_ok = (palavras_reais[0] in texto_norm) and (palavras_reais[-1] in texto_norm)
            if not (regra1_ok or regra2_ok):
                continue
        elif len(palavras_reais) == 1:
            # Só 1 nome real digitado (ex: 'pg de yasmin') — exige bater
            if palavras_reais[0] not in texto_norm:
                continue
        else:
            # Caller já filtra len < 2 antes de chamar, então não deve cair aqui.
            # Mas se cair (só stopwords digitadas), rejeita por segurança.
            continue

        # Extrai valor (maior R$ X,XX do email). Não descarta se o valor não bater —
        # confia que o nome único é match suficiente. Quem confere o valor é o caller
        # (que pode logar/avisar mas não bloqueia confirmação).
        valor_email = None
        for match in _RE_VALOR_EMAIL.findall(texto_completo):
            v = _valor_str_to_float(match)
            if v is not None and (valor_email is None or v > valor_email):
                valor_email = v

        # Flag de match de valor — caller usa pra log/aviso, não pra descartar
        valor_ok = True
        if valor_minimo is not None and valor_email is not None:
            valor_ok = valor_email >= valor_minimo

        try:
            data_fmt = dt.strftime('%d/%m/%Y %H:%M')
        except Exception:
            data_fmt = data_raw[:30]

        # Nome do PAGADOR: SÓ vem do CORPO do email. O header From traz o nome
        # do BANCO (ex: "Inter", "Nubank") — isso NÃO é o pagador, NÃO entra aqui.
        # Se a extração do corpo falhar, deixa vazio e o caller faz o fallback
        # certo (nome_bonito = o que o cliente digitou no 'pg'). Nunca deixa o
        # nome do banco vazar pro campo de pagador.
        nome_pagador = _extrair_nome_pagador(texto_completo, assunto)

        encontrados.append({
            'remetente': nome_pagador,           # só nome do corpo, ou vazio
            'remetente_raw_from': _disp or addr,  # display/endereço do From (só pra log)
            'nome_pagador': nome_pagador,  # vazio se não conseguiu extrair do corpo
            'endereco': addr,
            'assunto': assunto,
            'data': data_fmt,
            'banco': banco,
            'valor': valor_email,
            'valor_ok': valor_ok,
            'valor_minimo': valor_minimo,
        })
        if len(encontrados) >= 10:
            break
    return encontrados


def buscar_emails_por_nome(termos_norm):
    """Versão antiga: abre conexão IMAP a cada chamada. Mantida pra compat
    (qualquer caller externo continua funcionando), mas o flow do pg agora
    usa buscar_emails_em_conexao com conexão reutilizada."""
    if not GMAIL_USUARIO or not GMAIL_SENHA_IMAP:
        raise RuntimeError('Gmail não configurado')
    m = _conectar_imap()
    try:
        return buscar_emails_em_conexao(m, termos_norm, max_emails_recentes=300)
    finally:
        try:
            m.logout()
        except Exception:
            pass


async def _buscar_emails_async(termos_norm):
    """Roda a busca IMAP num executor pra não travar o loop do discord.
    (Versão antiga — abre conexão a cada chamada. Usado só pra calls externas.)"""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, buscar_emails_por_nome, termos_norm)


async def _conectar_imap_async():
    """Conecta IMAP num executor pra não travar o loop."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _conectar_imap)


async def _buscar_em_conexao_async(m, termos_norm, max_emails=50, minutos=2):
    """Reusa conexão IMAP já aberta — muito mais rápido.
    Filtra emails dos últimos `minutos` minutos."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None, buscar_emails_em_conexao, m, termos_norm, max_emails, minutos
    )


def _imap_logout_silencioso(m):
    """Logout sem propagar erro — usado em finally."""
    try:
        m.logout()
    except Exception:
        pass


# ═════════════════════════════════════════════════════════════
# SalasBot API — busca config (apelidos + key) do configurador
# e cria sala via salas-bot.freefireapi.online
# ═════════════════════════════════════════════════════════════
async def _fetch_config_configurador():
    """Busca apelidos + key salasbot + key anthropic + saldo_salas do configurador
    (endpoint /bot/config). Atualiza as globais _apelidos_modo, _salas_oauth_key,
    _anthropic_key e _saldo_salas. Não levanta exceção — qualquer erro vira log.
    Em caso de falha, mantém o estado anterior pra não derrubar o bot."""
    global _apelidos_modo, _salas_oauth_key, _anthropic_key, _saldo_salas

    if not CONFIGURADOR_URL:
        return

    # Passa client_id como query param pra trazer saldo desse cliente especificamente.
    url = f"{CONFIGURADOR_URL}/bot/config?client_id={CLIENT_ID}"
    headers = {'X-Bot-Secret': BOT_FETCH_SECRET}
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as r:
                if r.status != 200:
                    print(f"[{stamp()}] [CFG-FETCH] ⚠️ HTTP {r.status} ao buscar config: {(await r.text())[:200]}", flush=True)
                    return
                data = await r.json()
    except Exception as e:
        print(f"[{stamp()}] [CFG-FETCH] ⚠️ Erro de rede: {e}", flush=True)
        return

    if not data.get('ok'):
        print(f"[{stamp()}] [CFG-FETCH] ⚠️ Configurador respondeu não-ok: {data.get('msg', data)}", flush=True)
        return

    # Atualiza apelidos — normaliza chave pra lowercase
    novos = {}
    for item in (data.get('apelidos') or []):
        ap = (item.get('apelido') or '').strip().lower()
        try:
            modo = int(item.get('modo'))
        except (ValueError, TypeError):
            continue
        if ap and modo in (1, 2, 3, 4, 5):
            novos[ap] = modo
    _apelidos_modo = novos

    _salas_oauth_key = (data.get('salas_key') or '').strip()
    # Aceita 'anthropic_key' (novo) ou 'gemini_key' (legado) por compat.
    # Quando o configurador velho ainda responder 'gemini_key', o bot novo
    # não usa — mas não quebra. Tendência é o admin atualizar pra anthropic.
    _anthropic_key = (data.get('anthropic_key') or '').strip()

    # Saldo de salas — pode vir None se configurador é versão antiga.
    # Nesse caso, mantemos _saldo_salas em None (libera criação sem checar).
    saldo_raw = data.get('saldo_salas')
    if saldo_raw is not None:
        try:
            _saldo_salas = int(saldo_raw)
        except (ValueError, TypeError):
            _saldo_salas = None
    saldo_str = f"saldo={_saldo_salas}" if _saldo_salas is not None else "saldo=N/A"

    print(f"[{stamp()}] [CFG-FETCH] ✅ {len(_apelidos_modo)} apelido(s) carregado(s). "
          f"SalasBot: {'OK' if _salas_oauth_key else '⚠️ vazia'}, "
          f"OCR Claude: {'OK' if _anthropic_key else '⚠️ vazia (OCR de imagens desativado)'}, "
          f"{saldo_str}", flush=True)


async def _debitar_saldo_no_configurador():
    """Chama POST /bot/debitar-saldo no configurador pra decrementar -1.
    Atualiza _saldo_salas com a resposta. Idempotência fica do lado do
    configurador (se ele preferir, pode usar request_id no body — mas
    aqui chamamos uma vez por sala criada com sucesso, então não duplica)."""
    global _saldo_salas
    if not CONFIGURADOR_URL:
        return
    url = f"{CONFIGURADOR_URL}/bot/debitar-saldo"
    headers = {'X-Bot-Secret': BOT_FETCH_SECRET, 'Content-Type': 'application/json'}
    body = {'client_id': CLIENT_ID}
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(url, headers=headers, json=body, timeout=aiohttp.ClientTimeout(total=10)) as r:
                if r.status != 200:
                    print(f"[{stamp()}] [SALDO] ⚠️ HTTP {r.status} ao debitar saldo: {(await r.text())[:200]}", flush=True)
                    return
                data = await r.json()
                if data.get('ok'):
                    novo = data.get('saldo_salas')
                    if novo is not None:
                        try:
                            _saldo_salas = int(novo)
                            print(f"[{stamp()}] [SALDO] 💳 Saldo debitado: agora {_saldo_salas} sala(s) restantes.", flush=True)
                        except (ValueError, TypeError):
                            pass
                else:
                    print(f"[{stamp()}] [SALDO] ⚠️ Configurador retornou não-ok: {data.get('msg', data)}", flush=True)
    except Exception as e:
        print(f"[{stamp()}] [SALDO] ⚠️ Erro de rede ao debitar saldo: {e}", flush=True)


async def _reportar_erro_sala_no_configurador(tipo, msg):
    """Reporta falha de criacao de sala pro configurador. NADA vai no canal."""
    if not CONFIGURADOR_URL:
        return
    url = f"{CONFIGURADOR_URL}/bot/erro-sala"
    headers = {'X-Bot-Secret': BOT_FETCH_SECRET, 'Content-Type': 'application/json'}
    body = {'client_id': CLIENT_ID, 'tipo': tipo, 'msg': str(msg)[:300]}
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(url, headers=headers, json=body,
                              timeout=aiohttp.ClientTimeout(total=10)) as r:
                if r.status != 200:
                    print(f"[{stamp()}] [ERRO-SALA] HTTP {r.status} ao reportar.", flush=True)
    except Exception as e:
        print(f"[{stamp()}] [ERRO-SALA] Falha ao reportar: {e}", flush=True)


def _classificar_erro_sala(erro):
    e = str(erro or '').upper()
    if 'BRIDGE' in e or 'INDISPON' in e or '503' in e or 'UNAVAILABLE' in e:
        return 'BRIDGE_OFFLINE'
    if 'TIMEOUT' in e:
        return 'TIMEOUT'
    if '401' in e or 'AUTH' in e or 'TOKEN' in e or 'KEY' in e:
        return 'AUTH'
    return 'OUTRO'


async def fetch_config_loop():
    """Busca config a cada 5min em loop. Roda em paralelo com on_message."""
    while True:
        try:
            await _fetch_config_configurador()
        except Exception as e:
            print(f"[{stamp()}] [CFG-FETCH] erro inesperado no loop: {e}", flush=True)
        await asyncio.sleep(300)  # 5min


def _erro_eh_retryable(erro_status, erro_msg, http_status):
    """Decide se um erro é transitório (vale tentar outra URL ou esperar) vs
    permanente (auth ruim, modo inválido — não adianta tentar de novo).

    Retornáveis (vale failover/retry):
      - BRIDGE_OFFLINE (bridge interna da SalasBot caiu)
      - 502/503/504 (gateway/serviço indisponível)
      - 500 (erro interno transitório)
      - "indisponivel" / "unavailable" no texto
      - timeout / connection errors (já tratados no caller)

    Não-retornáveis (desiste imediato):
      - 401/403 AUTH
      - 400 modo/senha inválido
      - 404 endpoint errado
    """
    s = str(erro_status or '').upper()
    m = str(erro_msg or '').upper()
    if http_status in (500, 502, 503, 504):
        return True
    if 'BRIDGE_OFFLINE' in s or 'BRIDGE_OFFLINE' in m:
        return True
    if 'BRIDGE' in s and 'OFFLINE' in s:
        return True
    if 'INDISPON' in m or 'UNAVAILABLE' in m:
        return True
    if 'SERVICO INTERNO' in m or 'SERVIÇO INTERNO' in m:
        return True
    return False


async def _criar_sala_api(modo, nome_sala, base_url=None):
    """Cria sala via POST {base_url}/api/v1/create:room.
    Retorna dict com {ok, roomId, senha, nome, modoCriado, sshash, msg_erro,
                       rate_limited, retry_after, retryable, base_url_usada}.
    Trata todos os códigos de erro documentados (401/429/503/400).

    Se base_url=None, usa SALAS_API_URLS[0] (primária). A função em si tenta
    UMA URL — o failover entre URLs fica no caller (_criar_sala_com_retry).
    """
    if not _salas_oauth_key:
        return {'ok': False, 'msg_erro': 'Key SalasBot não configurada no configurador.', 'retryable': False}
    if modo not in (1, 2, 3, 4, 5):
        return {'ok': False, 'msg_erro': f'Modo inválido: {modo}', 'retryable': False}

    if base_url is None:
        base_url = SALAS_API_URLS[0]
    base_url = base_url.rstrip('/')

    body = {'modo': modo, 'nome': (SALA_NOME or nome_sala or 'Sala')[:30]}
    if SENHA_SALA and SENHA_SALA.isdigit():
        body['senha'] = SENHA_SALA
    if AUTO_START > 0:
        body['auto_start'] = AUTO_START

    headers = {
        'Authorization': _salas_oauth_key,
        'Content-Type': 'application/json',
    }

    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(
                f'{base_url}/api/v1/create:room',
                headers=headers, json=body,
                timeout=aiohttp.ClientTimeout(total=20),
            ) as r:
                try:
                    data = await r.json()
                except Exception:
                    txt = await r.text()
                    # Resposta não-JSON com 5xx = quase certo que é servidor caído,
                    # vale tentar outra URL. 4xx não-JSON = bug do servidor mas
                    # provavelmente vai dar igual em qualquer endpoint.
                    return {
                        'ok': False,
                        'msg_erro': f'Resposta inválida (HTTP {r.status}): {txt[:120]}',
                        'retryable': r.status >= 500,
                        'base_url_usada': base_url,
                    }

                if r.status == 200 and data.get('status') == 'SALA_CRIADA':
                    return {
                        'ok': True,
                        'roomId': data.get('roomId', '?'),
                        'senha': data.get('senha', ''),
                        'nome': data.get('nome', nome_sala),
                        'modoCriado': data.get('modoCriado', f'modo {modo}'),
                        'sshash': data.get('sshash', ''),
                        'base_url_usada': base_url,
                    }

                # Erro — extrai mensagem
                erro_status = data.get('status') or data.get('error') or f'HTTP {r.status}'
                erro_msg = data.get('msg') or data.get('message') or 'erro desconhecido'

                # Detecta rate limit (429 ou status indicativo) e extrai segundos pra esperar.
                # A SalasBot pode responder com retry_after_seconds / retryAfter / wait /
                # ou via header Retry-After (segundos). Default 30s se 429 mas sem hint.
                retry_after = None
                if r.status == 429 or 'RATE_LIMIT' in str(erro_status).upper() or 'rate' in str(erro_msg).lower():
                    for chave in ('retry_after_seconds', 'retry_after', 'retryAfter', 'wait', 'wait_seconds'):
                        val = data.get(chave)
                        if val is not None:
                            try:
                                retry_after = int(float(val))
                                break
                            except (ValueError, TypeError):
                                pass
                    if retry_after is None:
                        hdr = r.headers.get('Retry-After')
                        if hdr:
                            try:
                                retry_after = int(float(hdr))
                            except (ValueError, TypeError):
                                pass
                    if retry_after is None:
                        retry_after = 30  # fallback razoável
                    return {
                        'ok': False,
                        'rate_limited': True,
                        'retry_after': retry_after,
                        'msg_erro': f'{erro_status}: {erro_msg} (retry em {retry_after}s)',
                        'retryable': False,  # rate-limit é tratado separado
                        'base_url_usada': base_url,
                    }

                # Erro qualquer — marca se vale tentar de novo ou cair pro próximo endpoint
                retryable = _erro_eh_retryable(erro_status, erro_msg, r.status)
                return {
                    'ok': False,
                    'msg_erro': f'{erro_status}: {erro_msg}',
                    'retryable': retryable,
                    'base_url_usada': base_url,
                }
    except asyncio.TimeoutError:
        return {
            'ok': False,
            'msg_erro': f'Timeout ao falar com SalasBot API ({base_url}).',
            'retryable': True,
            'base_url_usada': base_url,
        }
    except aiohttp.ClientConnectorError as e:
        # DNS, connection refused, SSL errors — vale tentar outra URL
        return {
            'ok': False,
            'msg_erro': f'Erro de conexão ({base_url}): {e}',
            'retryable': True,
            'base_url_usada': base_url,
        }
    except Exception as e:
        return {
            'ok': False,
            'msg_erro': f'Erro de rede: {e}',
            'retryable': True,
            'base_url_usada': base_url,
        }


async def _iniciar_sala_api(sshash, room_id=None, base_url=None):
    """Inicia a partida via POST {base_url}/api/v2/start:room.

    Doc oficial: o endpoint é v2 (não v1), exige sshash no body, e a resposta
    de sucesso é status='PARTIDA_INICIADA'. Mando enviar_msg=false pra suprimir
    o countdown nativo da SalasBot — quem mostra a caixa "SALA INICIADA" é o
    bot daqui, então não precisa o duplo aviso.

    base_url: se None, usa SALAS_API_URLS[0] (primária). Idealmente quem chama
    passa a base_url que foi usada com sucesso pra criar a sala — porque o
    sshash é específico do endpoint que criou (se criou em salasff.com, tem
    que iniciar em salasff.com também, NÃO no freefireapi.online).

    Retorna dict com {ok, msg_erro, rate_limited, retry_after, retryable}.
    """
    if not _salas_oauth_key:
        return {'ok': False, 'msg_erro': 'Key SalasBot não configurada no configurador.'}
    if not sshash:
        return {'ok': False, 'msg_erro': 'sshash não disponível — sala não foi criada via API.'}

    if base_url is None:
        base_url = SALAS_API_URLS[0]
    base_url = base_url.rstrip('/')

    body = {'sshash': sshash, 'enviar_msg': False}

    headers = {
        'Authorization': _salas_oauth_key,
        'Content-Type': 'application/json',
    }

    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(
                f'{base_url}/api/v2/start:room',
                headers=headers, json=body,
                timeout=aiohttp.ClientTimeout(total=20),
            ) as r:
                # Tenta parsear como JSON; se vier HTML/texto puro, devolve o
                # texto cru pra debug (sshash inválido pode dar 404 com body
                # JSON {"error":"SSHASH_INVALIDO"} ou HTML genérico).
                try:
                    data = await r.json()
                except Exception:
                    txt = await r.text()
                    print(f"[{stamp()}] [START_ROOM] ⚠️ Resposta não-JSON (HTTP {r.status}): {txt[:200]}", flush=True)
                    return {'ok': False, 'msg_erro': f'Resposta inválida (HTTP {r.status}): {txt[:120]}'}

                # Log da resposta crua sempre — barato e ajuda muito a debugar
                print(f"[{stamp()}] [START_ROOM] HTTP {r.status} resp={data}", flush=True)

                if r.status == 200 and (
                    data.get('status') in ('PARTIDA_INICIADA', 'SALA_INICIADA', 'INICIADA', 'OK', 'ok', 'COMECANDO', 'INICIANDO') or
                    data.get('success') == 'ok' or
                    data.get('ok') is True
                ):
                    # COMECANDO = sala já está começando (alguém chamou antes,
                    # ou call duplicada). Trata como sucesso — não precisa alarmar
                    # o cliente nem postar erro no canal.
                    return {'ok': True}

                # Erro — extrai mensagem
                erro_status = data.get('status') or data.get('error') or f'HTTP {r.status}'
                erro_msg = data.get('msg') or data.get('message') or 'erro desconhecido'

                # Rate limit (doc: 429 RATE_LIMITED, 1.2s entre criações por key —
                # provavelmente vale aqui também já que é a mesma key)
                retry_after = None
                if r.status == 429 or 'RATE_LIMIT' in str(erro_status).upper() or 'rate' in str(erro_msg).lower():
                    for chave in ('retry_after_seconds', 'retry_after', 'retryAfter', 'wait', 'wait_seconds'):
                        val = data.get(chave)
                        if val is not None:
                            try:
                                retry_after = int(float(val))
                                break
                            except (ValueError, TypeError):
                                pass
                    if retry_after is None:
                        hdr = r.headers.get('Retry-After')
                        if hdr:
                            try:
                                retry_after = int(float(hdr))
                            except (ValueError, TypeError):
                                pass
                    if retry_after is None:
                        retry_after = 2  # doc diz 1.2s, deixo folga
                    return {
                        'ok': False,
                        'rate_limited': True,
                        'retry_after': retry_after,
                        'msg_erro': f'{erro_status}: {erro_msg} (retry em {retry_after}s)',
                    }

                return {'ok': False, 'msg_erro': f'{erro_status}: {erro_msg}'}
    except asyncio.TimeoutError:
        return {'ok': False, 'msg_erro': 'Timeout ao falar com SalasBot API.'}
    except Exception as e:
        return {'ok': False, 'msg_erro': f'Erro de rede: {e}'}


# Trava anti-spam: canais que já receberam MENSAGEM_AUTO nesta execução do bot.
# Reseta a cada restart. Se a sala for nova após restart, dispara de novo (ok).
_canais_ja_respondidos = set()

# Valor da sala extraído de mensagens de bots no canal.
# {canal_id_str: valor_float}. Sobrescreve a cada nova msg de bot com valor.
_valor_por_canal = {}

# Modo detectado a partir do primeiro apelido visto no canal.
# {canal_id_str: int (1-5)}. Definido na 1ª msg do canal que contém apelido conhecido —
# depois disso fica TRAVADO até o canal ser limpo de _canais_ja_respondidos (1x por restart).
_modo_por_canal = {}


def _detectar_modo_pelo_nome_canal(canal):
    """Procura apelidos cadastrados no NOME do canal (ex: '1v1 Gel Infinito | Mobile').
    Tokeniza igual à detecção por mensagem: normaliza acento/case + split por
    espaço/pontuação. Retorna o modo (1-5) do apelido MAIS ESPECÍFICO (mais longo)
    encontrado, ou None se nada bater.

    Útil porque clientes nomeiam os canais com o modo (ex: 'Gel Infinito',
    'Full Capa') e não precisamos esperar uma mensagem mencionar o apelido.

    Antes era first-match-wins (parava no primeiro token que casava). Agora
    escaneia tudo e pega o mais específico — evita 'Gel Infinito' virar modo 1
    porque '1v1' veio antes no nome.
    """
    if not _apelidos_modo:
        return None
    nome = getattr(canal, 'name', '') or ''
    if not nome:
        return None
    try:
        nome_norm = _norm(nome)
        tokens = re.split(r'[\s.,;:!?/\\|()\[\]{}\-_*"\'`]+', nome_norm)
        candidatos = []
        for tok in tokens:
            if tok and tok in _apelidos_modo:
                candidatos.append((tok, _apelidos_modo[tok]))
        if candidatos:
            candidatos.sort(key=lambda x: -len(x[0]))
            return candidatos[0][1]
    except Exception:
        pass
    return None

# Apelidos globais — { 'inf': 3, 'normal': 1, ... } — populado pela task fetch_config_loop
# e pelo bootstrap inicial. Acesso só leitura no on_message (sem lock necessário).
_apelidos_modo = {}
_salas_oauth_key = ''  # key da SalasBot API, atualizada pela mesma task
_anthropic_key = ''    # key da Anthropic (Claude Haiku) pra ler comprovantes
_saldo_salas = None    # saldo atual do cliente; None = ainda não buscou (deixa criar 1ª sala)

# Conta pgs confirmados por canal. Sala é criada quando chega a 2.
# {ch_id_str: int}. Resetado ao restart do bot.
_pgs_confirmados_por_canal = {}

# Canais que já criaram sala nesta execução — evita criar 2 salas se vier um 3º pg.
_sala_criada_canal = set()

# Detecção de "go": quando 2 pessoas mandam "go" no mesmo canal,
# o bot posta "Sala iniciada". 1x por canal por execução.
# {ch_id_str: set(user_id)} — set de usuários únicos que deram go.
_gos_por_canal = {}
_sala_iniciada_canal = set()

# Dados da sala criada por canal, pra usar no start_room. Salvo após criação.
# {ch_id_str: {'sshash': str, 'roomId': str, 'senha': str, 'modo': int}}
_dados_sala_canal = {}

# === GATE de ativação por canal (modo PIX_AUTO_ATIVO) ===
# Quando PIX_AUTO_ATIVO=True, o bot fica passivo em cada canal monitorado
# até detectar a chave PIX DESTE cliente postada lá. A partir desse momento,
# o canal entra em _canais_ativados e o bot começa a processar PG/GO/apelidos/
# comprovantes/PIX_AUTO naquele canal.
#
# Por que: garante que o bot só age depois que o próprio cliente postou a
# chave PIX no canal (sinal explícito de "esse canal é meu, tô vendendo aqui").
# Evita ações em canais monitorados que ainda não tiveram venda iniciada.
#
# Quando PIX_AUTO_ATIVO=False, esse gate NÃO se aplica — bot age direto em
# qualquer canal monitorado (comportamento legado).
#
# Set é por execução do bot — restart limpa e o cliente precisa repostar a
# chave (intencional: evita estado órfão; reinício é raro o bastante pra
# não atrapalhar o operador).
_canais_ativados = set()


def _canal_pode_agir(message):
    """Retorna True se o bot deve processar este canal agora.

    Regra:
      - PIX_AUTO_ATIVO=False → True sempre (modo legado: bot age em qualquer
        canal monitorado, sem precisar de gate)
      - PIX_AUTO_ATIVO=True  → True só se o canal já foi "ativado" via
        postagem da chave PIX. Antes disso, bot fica passivo (não responde
        PG, não conta GO, não processa comprovantes, não detecta apelido).
    """
    if not PIX_AUTO_ATIVO:
        return True
    ch_id = str(message.channel.id)
    return ch_id in _canais_ativados

# Buscas pg em andamento, pra ignorar duplicata do mesmo usuário no mesmo canal.
# Set de tuplas (canal_id_str, autor_id_int). Remove quando termina.
_buscas_em_andamento = set()

# Trava anti-duplicata por message.id — Discord às vezes entrega a mesma msg 2x.
# Usa deque limitado pra não vazar memória; mantém últimas 500 ids.
from collections import deque
_msgs_processadas = deque(maxlen=500)
_msgs_processadas_set = set()  # busca O(1)

# Regex pra extrair "R$ X,XX" / "R$X.XX" / "R$ 1.234,56"
_RE_VALOR_BR = re.compile(r'R\$\s*(\d{1,6}(?:[.,]\d{3})*[.,]\d{2})')


def _texto_completo_msg(message):
    """Retorna texto da mensagem incluindo embeds.

    Mensagens de bots (Whale Apostas, etc) usam embeds — o `message.content`
    fica vazio e o conteúdo real (valor, chave PIX, instruções) está em
    `embed.title`, `embed.description`, `embed.fields`, etc. Pra detecções
    como PIX_KEY ou valor R$, precisamos do texto unificado.

    Junta na ordem: content → cada embed (title, description, author.name,
    footer.text, todos os fields name+value). Separados por espaço pra que
    `texto in texto_completo` funcione mesmo se o PIX_KEY estiver dividido
    entre campos.
    """
    partes = []
    try:
        if message.content:
            partes.append(str(message.content))
    except Exception:
        pass
    for emb in (getattr(message, 'embeds', None) or []):
        try:
            if emb.title: partes.append(str(emb.title))
            if emb.description: partes.append(str(emb.description))
            if emb.footer and emb.footer.text: partes.append(str(emb.footer.text))
            if emb.author and emb.author.name: partes.append(str(emb.author.name))
            for f in (emb.fields or []):
                if f.name: partes.append(str(f.name))
                if f.value: partes.append(str(f.value))
        except Exception:
            pass
    return ' '.join(partes)


def _normalizar_pix(s):
    """Normaliza chave PIX pra comparação robusta.

    Remove: pontos, traços, espaços, parênteses, barras — qualquer separador
    visual que o cliente possa ter colocado (ou não) ao salvar a chave no
    painel vs ao postar no canal.

    Exemplos que ficam todos iguais depois da normalização:
      "544.693.568-32"
      "544 693 568 32"
      "54469356832"
      " 544.693.568-32 "
      "544-693-568.32"  (alguém digitou errado)

    Tudo vira: "54469356832"

    Funciona pra CPF, CNPJ, telefone, email (lowercase), aleatória.
    Pra email só faz lowercase (não tira o @ nem .).
    """
    if not s:
        return ''
    s = str(s).strip()
    # Se é email (tem @), só faz lowercase — não mexe nos caracteres
    if '@' in s:
        return s.lower()
    # Caso geral: remove tudo que não for letra/dígito
    import re as _re
    return _re.sub(r'[^a-zA-Z0-9]', '', s).lower()


# ═════════════════════════════════════════════════════════════
# OCR — extrai nome+valor de comprovantes anexados ao canal,
# pra usar como termos da busca IMAP quando o "pg" vier sem nome.
# ═════════════════════════════════════════════════════════════

# Cache do OCR mais recente por canal: {ch_id_str: {'nome': str, 'valor': float|None, 'ts': float}}
# Substituído a cada nova imagem postada no canal. TTL de 5min.
_ocr_por_canal = {}
_OCR_TTL_SEGUNDOS = 300  # 5min

# Autores cuja busca PG já foi disparada AUTOMATICAMENTE pelo OCR — chave (ch_id_str, autor_id).
# Quando o cliente posta o comprovante, bot detecta sozinho e roda a busca. Se ele depois
# mandar 'pg nome', ignoramos pra não duplicar resposta. Limpa entradas antigas (>10min)
# pra não acumular indefinidamente.
_autores_com_comprovante = {}
_COMPROVANTE_TTL_SEGUNDOS = 600  # 10min — sobra de margem pra busca de 30s + qualquer pg tardio


def _ja_tem_comprovante_disparado(ch_id, autor_id):
    """True se o autor já teve uma busca automática disparada via OCR neste canal,
    dentro da janela de TTL. Usado pra ignorar 'pg' redundante."""
    chave = (str(ch_id), autor_id)
    ts = _autores_com_comprovante.get(chave)
    if ts is None:
        return False
    if time.time() - ts > _COMPROVANTE_TTL_SEGUNDOS:
        _autores_com_comprovante.pop(chave, None)
        return False
    return True

# Domínios pra reconhecer comprovantes brasileiros — não bloqueia outros, só ajuda
# o parser a focar no nome certo.
_OCR_PALAVRAS_DESCARTE = {
    # Cabeçalhos comuns
    'comprovante', 'transferencia', 'transferência', 'pix', 'enviado', 'pago',
    'recebido', 'recebimento', 'pagamento', 'efetuado', 'efetuada', 'realizado',
    'realizada', 'autenticacao', 'autenticação', 'codigo', 'código', 'protocolo',
    'data', 'hora', 'valor', 'tipo', 'destinatario', 'destinatário', 'origem',
    'pagador', 'recebedor', 'beneficiario', 'beneficiário', 'cpf', 'cnpj', 'banco',
    'agencia', 'agência', 'conta', 'chave', 'mensagem', 'instituicao', 'instituição',
    # Bancos / instituições
    'nubank', 'inter', 'picpay', 'banco', 'itau', 'itaú', 'bradesco', 'caixa',
    'santander', 'mercado', 'pago', 'mercadopago', 'next', 'c6', 'sicoob',
    'sicredi', 'bb', 'brasil', 'original', 'pan', 'neon', 'will', 'pagseguro',
    'asaas', 'efi', 'efipay', 'cora', 'stone', 'safra', 'btg', 'pactual', 'pactual',
    # Outras palavras frequentes
    'real', 'reais', 'r$', 'r', 'rs', 'sucesso', 'concluida', 'concluído',
    'transacao', 'transação', 'id', 'numero', 'número',
    'app', 'aplicativo', 'mobile', 'recibo', 'boleto', 'qrcode', 'qr',
    'segunda', 'terca', 'terça', 'quarta', 'quinta', 'sexta', 'sabado', 'sábado', 'domingo',
    'janeiro', 'fevereiro', 'marco', 'março', 'abril', 'maio', 'junho', 'julho',
    'agosto', 'setembro', 'outubro', 'novembro', 'dezembro',
    'jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez',
    'enviou', 'voce', 'você', 'para', 'de', 'em', 'no', 'na', 'do', 'da',
}

# Regex pra detectar CPF formatado (XXX.XXX.XXX-XX) — útil pra encontrar o bloco do pagador
_RE_CPF = re.compile(r'\d{3}\.\d{3}\.\d{3}-\d{2}|\d{3}\.\*{3}\.\d{3}-\d{2}|\*{3}\.\d{3}\.\d{3}-\*{2}')

# Set pra travar processamento de imagens duplicadas (por URL do attachment)
_imgs_ocr_processadas = deque(maxlen=200)
_imgs_ocr_set = set()


# ════════════════════════════════════════════════════════════════════
# LEITURA DE COMPROVANTES — Anthropic Claude Haiku (claude-haiku-4-5)
# Recebe a imagem do comprovante e pede pro modelo extrair nome+valor
# direto. Sem regex, sem heurística manual: o modelo entende o layout
# de qualquer banco/comprovante.
# Doc: https://docs.claude.com/en/api/messages
# ════════════════════════════════════════════════════════════════════
_ANTHROPIC_MODEL = 'claude-haiku-4-5'
_ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages'
_ANTHROPIC_VERSION = '2023-06-01'

_OCR_PROMPT = """Você recebe uma imagem postada num chat brasileiro de Free Fire onde clientes pagam por PIX pra entrar em salas.

Sua tarefa: olhar a imagem e extrair 3 informações.

Responda APENAS um JSON puro, sem markdown, sem ```, sem texto antes ou depois:
{"tipo":"...","nome":"...","valor":...}

Campos:

- "tipo": string. Identifique o que é:
  * "comprovante" → se é um comprovante/recibo de pagamento PIX (de qualquer banco: Nubank, Inter, Itaú, Bradesco, PicPay, Mercado Pago, C6, Caixa, Banco do Brasil, etc)
  * "screenshot_jogo" → se é screenshot de Free Fire ou outro jogo (não é comprovante)
  * "outro" → se é outra coisa (foto pessoal, meme, conversa, etc)

- "nome": string ou null. Se for comprovante, o NOME COMPLETO de quem ENVIOU o dinheiro (pagador/origem, NÃO o destinatário/recebedor). Se não for comprovante OU se realmente não dá pra ler o nome, use null. SEMPRE tente ler o nome mesmo se a foto tiver qualidade ruim — só use null como último recurso.

- "valor": número (float) ou null. Se for comprovante, o valor pago em reais (ex: 5.00, 12.50, 2.00). Se não for comprovante OU se não conseguir ler, use null.

Exemplos:
{"tipo":"comprovante","nome":"Maria Silva Santos","valor":5.00}
{"tipo":"comprovante","nome":"João Pedro Oliveira","valor":10.00}
{"tipo":"screenshot_jogo","nome":null,"valor":null}
{"tipo":"outro","nome":null,"valor":null}"""


def _detectar_mime_real(image_bytes):
    """Detecta o mime real pelos magic bytes (primeiros bytes do arquivo).
    Necessário porque o `content_type` que o Discord nos passa muitas vezes
    está errado — usuários de iPhone tipicamente postam .png renomeado como
    .jpg, e o Discord propaga isso como image/jpeg.

    A Anthropic agora valida o conteúdo da imagem contra o media_type declarado
    e rejeita com HTTP 400 se não bater:

        "The image was specified using the image/jpeg media type, but the
         image appears to be a image/png image"

    Solução: ignora o content_type recebido e usa o que os magic bytes dizem.

    Retorna 'image/png', 'image/jpeg', 'image/webp', 'image/gif' ou None
    (se não conseguir identificar — caller decide o fallback).
    """
    if not image_bytes or len(image_bytes) < 12:
        return None
    # PNG: 89 50 4E 47 0D 0A 1A 0A
    if image_bytes[:8] == b'\x89PNG\r\n\x1a\n':
        return 'image/png'
    # JPEG: FF D8 FF
    if image_bytes[:3] == b'\xff\xd8\xff':
        return 'image/jpeg'
    # WebP: RIFF....WEBP
    if image_bytes[:4] == b'RIFF' and image_bytes[8:12] == b'WEBP':
        return 'image/webp'
    # GIF: GIF87a or GIF89a
    if image_bytes[:6] in (b'GIF87a', b'GIF89a'):
        return 'image/gif'
    return None


async def _ocr_extrair_comprovante(image_bytes, content_type='image/png'):
    """Envia imagem do comprovante pra API da Anthropic (Claude Haiku) e extrai nome+valor.
    Retorna {'nome': str|None, 'valor': float|None, 'tipo': str, '_raw': str} ou None se erro/sem key.

    Por que Claude Haiku:
      - Multimodal nativo (aceita imagem direto, sem precisar OCR separado)
      - Mais barato da Anthropic (~$0.25/M input tokens, ~$1.25/M output)
      - 1 chamada extrai tudo (nome+valor+tipo) — sem regex frágil
      - JSON-mode confiável (raramente responde com prosa)
    """
    if not _anthropic_key:
        # Sem key configurada — silencioso. fetch_config_loop já avisou no log.
        return None

    # Anthropic aceita até 5MB de imagem (base64 inflado). Acima disso retorna 400.
    # Comprovantes geralmente <500KB. Comprime/avisa se passar.
    if len(image_bytes) > 4_500_000:
        print(f"[{stamp()}] [OCR] ⚠️ Imagem grande ({len(image_bytes)} bytes), pode ser rejeitada.", flush=True)

    # ─── Detecção de mime REAL pelos magic bytes ───
    # NUNCA confia no content_type — fotos de iPhone vêm com content_type errado
    # ('image/jpeg' mas conteúdo PNG). A Anthropic rejeita HTTP 400 se não bater.
    mime_real = _detectar_mime_real(image_bytes)
    if mime_real:
        # Confiável: usa o que os bytes dizem
        if (content_type or '').lower() and mime_real != (content_type or '').lower():
            print(f"[{stamp()}] [OCR] 🔧 content_type={content_type} mas magic bytes dizem {mime_real}. Usando o real.", flush=True)
        mime = mime_real
    else:
        # Fallback: tenta o content_type, normalizado
        mime = (content_type or 'image/png').lower()
        if 'jpeg' in mime or 'jpg' in mime:
            mime = 'image/jpeg'
        elif 'webp' in mime:
            mime = 'image/webp'
        elif 'gif' in mime:
            mime = 'image/gif'
        elif 'png' in mime:
            mime = 'image/png'
        else:
            mime = 'image/jpeg'  # fallback razoável
        print(f"[{stamp()}] [OCR] ⚠️ Não consegui detectar magic bytes (len={len(image_bytes)}). Usando content_type fallback: {mime}", flush=True)

    import base64
    img_b64 = base64.b64encode(image_bytes).decode('ascii')

    # Payload no formato Messages API. Imagem como content block tipo "image"
    # com source base64. Texto como content block tipo "text".
    payload = {
        'model': _ANTHROPIC_MODEL,
        'max_tokens': 300,         # JSON resposta é pequeno (~80 tokens) — 300 dá folga
        'temperature': 0.0,         # determinístico — não inventa
        'messages': [
            {
                'role': 'user',
                'content': [
                    {
                        'type': 'image',
                        'source': {
                            'type': 'base64',
                            'media_type': mime,
                            'data': img_b64,
                        },
                    },
                    {'type': 'text', 'text': _OCR_PROMPT},
                ],
            }
        ],
    }

    headers = {
        'Content-Type': 'application/json',
        'x-api-key': _anthropic_key,
        'anthropic-version': _ANTHROPIC_VERSION,
    }

    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(
                _ANTHROPIC_URL,
                json=payload,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=25),
            ) as r:
                if r.status == 429:
                    print(f"[{stamp()}] [OCR] ⚠️ Rate limit (HTTP 429). Quota Anthropic esgotada — espera ~1min.", flush=True)
                    return None
                if r.status in (401, 403):
                    print(f"[{stamp()}] [OCR] ❌ Auth falhou (HTTP {r.status}). Key Anthropic inválida ou revogada.", flush=True)
                    return None
                if r.status >= 500:
                    print(f"[{stamp()}] [OCR] ⚠️ Anthropic indisponível (HTTP {r.status}). Tentar de novo depois.", flush=True)
                    return None
                if r.status != 200:
                    txt = (await r.text())[:300]
                    print(f"[{stamp()}] [OCR] ❌ HTTP {r.status}: {txt}", flush=True)
                    return None

                data = await r.json()
    except asyncio.TimeoutError:
        print(f"[{stamp()}] [OCR] ❌ Timeout (25s).", flush=True)
        return None
    except Exception as e:
        print(f"[{stamp()}] [OCR] ❌ Erro de rede: {e}", flush=True)
        return None

    # Resposta Anthropic: {content: [{type: 'text', text: '{"tipo":...}'}]}
    try:
        content = data.get('content') or []
        if not content:
            stop_reason = data.get('stop_reason', 'desconhecido')
            print(f"[{stamp()}] [OCR] ⚠️ Resposta sem content (stop_reason={stop_reason}): {str(data)[:200]}", flush=True)
            return None

        # Pega o primeiro bloco de texto. Em raríssimos casos pode ter
        # múltiplos blocos — junta tudo pra parsing robusto.
        textos = [b.get('text', '') for b in content if b.get('type') == 'text']
        texto_resp = '\n'.join(textos).strip()
        if not texto_resp:
            print(f"[{stamp()}] [OCR] ⚠️ Resposta de texto vazia (stop_reason={data.get('stop_reason')}).", flush=True)
            return None

        # Limpa fences markdown só pra garantir — Claude raramente faz isso
        # mas custa nada checar.
        if texto_resp.startswith('```'):
            linhas = [l for l in texto_resp.split('\n') if not l.startswith('```')]
            texto_resp = '\n'.join(linhas).strip()

        import json as _json
        try:
            parsed = _json.loads(texto_resp)
        except Exception as e:
            # Fallback: se o modelo respondeu com prosa antes do JSON
            # (raríssimo no Claude, mas mantemos defesa em profundidade)
            import re as _re
            parsed = None
            m = _re.search(r'\{[^{}]*"tipo"[^{}]*\}', texto_resp, _re.DOTALL)
            if m:
                try:
                    parsed = _json.loads(m.group(0))
                    print(f"[{stamp()}] [OCR] 🔧 JSON extraído via fallback regex de resposta com prosa.", flush=True)
                except Exception:
                    parsed = None

            if parsed is None:
                print(f"[{stamp()}] [OCR] ⚠️ JSON inválido ({e}): {texto_resp[:200]!r}", flush=True)
                return None

        # Sanitiza saída
        tipo = (parsed.get('tipo') or '').strip().lower() or 'desconhecido'

        nome = parsed.get('nome')
        if nome is not None:
            nome = str(nome).strip()
            if not nome or nome.lower() in ('null', 'none', 'n/a', ''):
                nome = None
            # Title case suave (igual ao parser antigo)
            if nome:
                nome = ' '.join(p.capitalize() if len(p) > 2 else p.lower() for p in nome.split())

        valor = parsed.get('valor')
        if valor is not None:
            try:
                valor = float(valor)
                if valor <= 0:
                    valor = None
            except (ValueError, TypeError):
                valor = None

        # _raw mantém compat com chamadores antigos que logavam diagnóstico
        return {'nome': nome, 'valor': valor, 'tipo': tipo, '_raw': texto_resp}

    except Exception as e:
        print(f"[{stamp()}] [OCR] ❌ Erro ao parsear resposta: {e}", flush=True)
        return None



async def _processar_comprovante_async(message_origem, attachment):
    """Baixa anexo, roda OCR, extrai nome+valor — e DISPARA AUTOMATICAMENTE a busca
    de pagamento (igual o `pg` faria). Antes era passivo (só salvava no cache pro
    próximo `pg` usar). Agora: bot age sozinho ao detectar comprovante.

    Comportamento:
      1. OCR extrai nome+valor da imagem
      2. Se tipo != 'comprovante' → salva no cache e retorna (não age)
      3. Se nome+valor extraídos → chama _buscar_e_responder_pg em modo silencioso
         - 0 ou 2+ matches: bot fica calado (logs ainda mostram pro admin)
         - 1 match: bot manda confirmação no canal mencionando quem postou
      4. Se confirmou, marca (ch_id, autor_id) como "já tem pagamento OK", pra
         o usuário não receber resposta dupla se mandar `pg nome` depois.

    Recebe a message inteira (não só o canal) pra:
      - Mencionar o autor do comprovante no log
      - Marcar `(ch_id, author.id)` na trava de duplicata
    """
    canal = message_origem.channel
    ch_id = str(canal.id)
    autor_id = message_origem.author.id
    autor_nome = getattr(message_origem.author, 'name', '?')

    url = getattr(attachment, 'url', '') or getattr(attachment, 'proxy_url', '')

    # Trava anti-duplicata (mesma imagem postada 2x — Discord às vezes re-edita)
    if url and url in _imgs_ocr_set:
        return
    if url:
        _imgs_ocr_processadas.append(url)
        _imgs_ocr_set.add(url)
        if len(_imgs_ocr_set) > len(_imgs_ocr_processadas):
            _imgs_ocr_set.intersection_update(set(_imgs_ocr_processadas))

    ch_nome = getattr(canal, 'name', '?')
    print(f"[{stamp()}] [OCR] 📸 Comprovante de @{autor_nome} em #{ch_nome} ({attachment.filename}, {attachment.size} bytes). Processando...", flush=True)

    try:
        # Baixa a imagem
        try:
            image_bytes = await attachment.read()
        except Exception as e:
            print(f"[{stamp()}] [OCR] ❌ Erro ao baixar anexo: {e}", flush=True)
            return

        content_type = getattr(attachment, 'content_type', '') or 'image/png'

        # Claude Haiku extrai nome+valor em uma chamada (não precisa OCR + parser)
        t0 = time.time()
        extraido = await _ocr_extrair_comprovante(image_bytes, content_type)
        dur = time.time() - t0

        if not extraido:
            print(f"[{stamp()}] [OCR] ❌ #{ch_nome}: extração falhou ({dur:.1f}s).", flush=True)
            return

        nome = extraido.get('nome')
        valor = extraido.get('valor')
        tipo = extraido.get('tipo', 'desconhecido')
        raw = extraido.get('_raw', '')

        if tipo == 'screenshot_jogo':
            print(f"[{stamp()}] [OCR] ⏭️ #{ch_nome}: imagem é screenshot do jogo, não comprovante. Ignorando.", flush=True)
            return
        if tipo == 'outro':
            print(f"[{stamp()}] [OCR] ⏭️ #{ch_nome}: imagem não é comprovante (tipo='outro'). Ignorando.", flush=True)
            return

        if not nome and valor is None:
            print(f"[{stamp()}] [OCR] ⚠️ #{ch_nome}: rodou ({dur:.1f}s) mas modelo retornou tipo='{tipo}' sem nome/valor.", flush=True)
            print(f"[{stamp()}] [OCR]    Resposta crua: {raw[:300]!r}", flush=True)
            return

        # Salva no cache do canal (fallback caso o usuário ainda mande `pg` solto)
        _ocr_por_canal[ch_id] = {
            'nome': nome,
            'valor': valor,
            'ts': time.time(),
        }

        nome_log = nome or '(sem nome)'
        valor_log = f"R$ {valor:.2f}" if valor is not None else '(sem valor)'
        print(f"[{stamp()}] [OCR] ✅ #{ch_nome}: tipo={tipo}, nome='{nome_log}', valor={valor_log} ({dur:.1f}s).", flush=True)

        # ─── DISPARO AUTOMÁTICO DA BUSCA PG ───
        # Só faz sentido se temos pelo menos um nome completo (2+ palavras) pra buscar.
        # Sem nome (só valor) o IMAP vai retornar muito ruído — não vale a pena.
        if not nome:
            print(f"[{stamp()}] [OCR] ⏭️ Sem nome do pagador — não disparando busca automática.", flush=True)
            return

        # Checa se canal pode agir (PIX_AUTO_ATIVO + chave PIX detectada)
        # Reusa a mesma função que o on_message usa pro pg.
        if not _canal_pode_agir(message_origem):
            print(f"[{stamp()}] [OCR] 🔒 #{ch_nome} ainda não ativado — não disparando busca.", flush=True)
            return

        termos = [_norm(p) for p in nome.split() if p.strip()]
        if len(termos) < 2:
            print(f"[{stamp()}] [OCR] ⏭️ Nome '{nome}' tem só {len(termos)} palavra(s) — busca silenciosa precisa de 2+.", flush=True)
            return

        # Marca esse autor como "tem busca rolando" pra ignorar `pg` dele depois.
        # Mesmo se a busca não achar nada, o pg do mesmo autor seria redundante
        # (provavelmente o nome do comprovante é o melhor termo de busca já).
        _autores_com_comprovante[(ch_id, autor_id)] = time.time()
        print(f"[{stamp()}] [OCR] 🤖 Disparando busca PG automática pra '{nome}'"
              f"{(' R$ ' + format(valor, '.2f')) if valor is not None else ''} (autor: @{autor_nome})", flush=True)

        # Valor mínimo: prioriza OCR > valor capturado de bot anterior
        valor_minimo = valor if valor is not None else _valor_por_canal.get(ch_id)

        # Chama a busca em modo silencioso (não posta "verificando...", só responde
        # se achar 1 match único). message=None faz a resposta ser canal.send em vez
        # de reply à msg da imagem (que pode estar lá em cima quando demorar 30s).
        # Mas como o autor do comprovante é importante, vamos responder COM reply
        # à mensagem do comprovante mesmo — passa message_origem.
        try:
            await _buscar_e_responder_pg(
                message=message_origem,
                canal=canal,
                autor_id=autor_id,
                autor_nome=autor_nome,
                consulta=nome,
                termos=termos,
                valor_minimo=valor_minimo,
                modo_silencioso=True,  # OCR é sempre silencioso — só responde se achar 1
                ch_id=ch_id,
                nome_ocr=nome,  # nome completo lido do comprovante — tem prioridade na resposta
            )
        except Exception as e:
            print(f"[{stamp()}] [OCR] ❌ Erro na busca automática: {e}", flush=True)

    except Exception as e:
        print(f"[{stamp()}] [OCR] ❌ Erro inesperado: {e}", flush=True)


def _ocr_pegar_do_canal(ch_id):
    """Retorna o último OCR válido (dentro do TTL) do canal, ou None se expirou/não tem."""
    d = _ocr_por_canal.get(str(ch_id))
    if not d:
        return None
    if (time.time() - d.get('ts', 0)) > _OCR_TTL_SEGUNDOS:
        # Expirou — limpa
        _ocr_por_canal.pop(str(ch_id), None)
        return None
    return d


async def _preparar_imagem_auto():
    """Retorna um discord.File a partir de IMAGEM_AUTO, ou None se vazio/erro.

    Aceita dois formatos:
    - data:image/...;base64,xxx  (upload do painel)
    - https://...                (URL externa)
    """
    src = IMAGEM_AUTO
    if not src:
        return None
    try:
        if src.startswith('data:'):
            try:
                cabecalho, dados = src.split(',', 1)
            except ValueError:
                print(f"[{stamp()}] [IMG] ❌ data URL malformada (sem vírgula).", flush=True)
                return None
            mime = cabecalho[5:].split(';')[0] or 'image/png'
            ext = mime.split('/')[-1] or 'png'
            try:
                raw = base64.b64decode(dados)
            except Exception as e:
                print(f"[{stamp()}] [IMG] ❌ erro decodificando base64: {e}", flush=True)
                return None
            return discord.File(io.BytesIO(raw), filename=f'comprovante.{ext}')

        if src.startswith('http://') or src.startswith('https://'):
            async with aiohttp.ClientSession() as s:
                async with s.get(src, timeout=aiohttp.ClientTimeout(total=8)) as r:
                    if r.status != 200:
                        print(f"[{stamp()}] [IMG] ❌ HTTP {r.status} ao baixar {src[:60]}", flush=True)
                        return None
                    raw = await r.read()
            ext = 'png'
            for cand in ('.png', '.jpg', '.jpeg', '.gif', '.webp'):
                if cand in src.lower():
                    ext = cand.lstrip('.')
                    break
            return discord.File(io.BytesIO(raw), filename=f'comprovante.{ext}')

        print(f"[{stamp()}] [IMG] ⚠️ IMAGEM_AUTO não é data URL nem HTTP, ignorando.", flush=True)
        return None
    except Exception as e:
        print(f"[{stamp()}] [IMG] ❌ Erro ao preparar imagem: {e}", flush=True)
        return None


def _valor_str_to_float(s):
    """'3,50' → 3.50 ; '3.50' → 3.50 ; '1.234,56' → 1234.56 ; '1,234.56' → 1234.56"""
    s = s.strip()
    # Detecta o separador decimal pelo ÚLTIMO símbolo presente
    last_dot = s.rfind('.')
    last_comma = s.rfind(',')
    if last_dot == -1 and last_comma == -1:
        try:
            return float(s)
        except Exception:
            return None
    if last_comma > last_dot:
        # Estilo BR: vírgula é decimal, ponto é milhar → tira pontos, troca vírgula por ponto
        s = s.replace('.', '').replace(',', '.')
    else:
        # Estilo internacional: ponto é decimal, vírgula é milhar → tira vírgulas
        s = s.replace(',', '')
    try:
        return float(s)
    except Exception:
        return None


def _caixa_simples(linhas, largura=34):
    """Caixa com cantos arredondados pra exibir no Discord — versão standalone
    (a outra _caixa fica dentro de on_message)."""
    borda_top = '╭' + ('─' * (largura - 2)) + '╮'
    borda_bot = '╰' + ('─' * (largura - 2)) + '╯'
    corpo = '\n'.join(f"│ {l}" for l in linhas)
    return f"{borda_top}\n{corpo}\n{borda_bot}"


def _montar_msg_pagamento(remetente, banco, valor_fmt, valor_ok=True, v_min=None, estilo=None):
    """Monta a mensagem de "Pagamento confirmado" no estilo escolhido pelo cliente.

    Estilos disponíveis (STILO_CAIXA):
      - 'pc' (default): caixa ╭─╮ + ✅ + "Banco: NUBANK" — visual atual,
        fica bonito no Discord PC mas no mobile alguns emojis empurram a borda.
      - 'mobile_estrela': caixa com cantos em + e linhas + + ... + +,
        usa ★ no lugar do ✅, remove o prefixo "Banco:" pra economizar largura.
        Bom no celular porque a fonte mono renderiza bem os + e tira ruído.
      - 'codeblock': mesma caixa de cantos +, porém envolvida num ```bloco
        de código``` do Discord. Render fica perfeitamente alinhado no mobile,
        custo é perder o **negrito** (codeblock não interpreta markdown).
      - 'compacto': sem caixa nenhuma, só as linhas em sequência. Menor possível.

    Args:
      remetente: nome do pagador (string)
      banco: nome do banco (string maiúscula)
      valor_fmt: 'R$ 0,85' ou similar; se None ou MOSTRAR_VALOR_PAGAMENTO=False,
                 a linha de valor é omitida
      valor_ok: se False, adiciona aviso de valor abaixo do esperado
      v_min: valor mínimo esperado (float), usado no aviso quando valor_ok=False
      estilo: override do STILO_CAIXA global (None usa o env var)
    """
    if estilo is None:
        estilo = STILO_CAIXA

    aviso_valor = None
    if not valor_ok and v_min is not None:
        v_min_fmt = f"R$ {v_min:.2f}".replace('.', ',')
        aviso_valor = f"valor abaixo do esperado ({v_min_fmt})"

    if estilo == 'mobile_estrela':
        # Caixa em cantos + e bordas + ──── +. Sem "Banco:", emojis simples.
        linhas = [
            f"★  **Pagamento confirmado**",
            f"👤  {remetente}",
            f"🏦  **{banco}**",
        ]
        if valor_fmt:
            linhas.append(f"💰  {valor_fmt}")
        if aviso_valor:
            linhas.append(f"⚠️  {aviso_valor}")
        largura = 32
        borda = '+' + ('─' * (largura - 2)) + '+'
        corpo = '\n'.join(f"  {l}" for l in linhas)
        return f"{borda}\n{corpo}\n{borda}"

    if estilo == 'codeblock':
        # Caixa em cantos + dentro de codeblock. SEM markdown (codeblock ignora **).
        linhas = [
            "PAGAMENTO CONFIRMADO",
            "",
            f"👤 {remetente}",
            f"🏦 {banco}",
        ]
        if valor_fmt:
            linhas.append(f"💰 {valor_fmt}")
        if aviso_valor:
            linhas.append(f"⚠️ {aviso_valor}")
        largura = 30
        borda = '+' + ('─' * (largura - 2)) + '+'
        corpo = '\n'.join(f"| {l}" for l in linhas)
        return f"```\n{borda}\n{corpo}\n{borda}\n```"

    if estilo == 'compacto':
        # Só as linhas, sem caixa.
        linhas = [
            f"✅  **Pagamento confirmado**",
            f"👤  {remetente}",
            f"🏦  **{banco}**",
        ]
        if valor_fmt:
            linhas.append(f"💰  {valor_fmt}")
        if aviso_valor:
            linhas.append(f"⚠️  {aviso_valor}")
        return '\n'.join(linhas)

    # estilo == 'pc' (default) — caixa arredondada original
    linhas = [
        "✅  **Pagamento confirmado**",
        f"👤  {remetente}",
        f"🏦  Banco: **{banco}**",
    ]
    if valor_fmt:
        linhas.append(f"💵  {valor_fmt}")
    if aviso_valor:
        linhas.append(f"⚠️  {aviso_valor}")
    return _caixa_simples(linhas, largura=34)


def _montar_msg_pg_nao_encontrado(nome_bonito, aviso_extra=None, estilo=None):
    """Versão da caixa pra quando o pagamento não foi encontrado.
    Espelha o estilo escolhido pra manter a identidade visual.
    """
    if estilo is None:
        estilo = STILO_CAIXA

    if estilo == 'mobile_estrela':
        linhas = [f"✕  **Pagamento não encontrado**", f"👤  {nome_bonito}"]
        if aviso_extra:
            linhas.append(f"⚠️  {aviso_extra}")
        largura = 32
        borda = '+' + ('─' * (largura - 2)) + '+'
        corpo = '\n'.join(f"  {l}" for l in linhas)
        return f"{borda}\n{corpo}\n{borda}"

    if estilo == 'codeblock':
        linhas = ["PAGAMENTO NAO ENCONTRADO", "", f"👤 {nome_bonito}"]
        if aviso_extra:
            linhas.append(f"⚠️ {aviso_extra}")
        largura = 30
        borda = '+' + ('─' * (largura - 2)) + '+'
        corpo = '\n'.join(f"| {l}" for l in linhas)
        return f"```\n{borda}\n{corpo}\n{borda}\n```"

    if estilo == 'compacto':
        linhas = [f"❌  **Pagamento não encontrado**", f"👤  {nome_bonito}"]
        if aviso_extra:
            linhas.append(f"⚠️  {aviso_extra}")
        return '\n'.join(linhas)

    # default 'pc'
    linhas = [f"❌  **Pagamento não encontrado**", f"👤  {nome_bonito}"]
    if aviso_extra:
        linhas.append(f"⚠️  {aviso_extra}")
    return _caixa_simples(linhas, largura=34)


async def _humano_typing_send(canal, conteudo, file=None, min_delay=0.6, max_delay=1.6, com_typing=True):
    """Envia mensagem com comportamento humanoide: typing indicator + delay aleatório.
    Bot que envia mensagem instantânea sem typing levanta suspeita; com esse helper
    todo envio parece um humano digitando.

    Args:
      canal: canal/thread/dm pra enviar.
      conteudo: texto da mensagem (str).
      file: discord.File opcional.
      min_delay, max_delay: range de espera (segundos).
      com_typing: se True, mostra "está digitando..." durante o delay.
    """
    delay = random.uniform(min_delay, max_delay)
    try:
        if com_typing:
            async with canal.typing():
                await asyncio.sleep(delay)
                if file is not None:
                    return await canal.send(conteudo, file=file)
                return await canal.send(conteudo)
        else:
            await asyncio.sleep(delay)
            if file is not None:
                return await canal.send(conteudo, file=file)
            return await canal.send(conteudo)
    except Exception as e:
        print(f"[{stamp()}] [HUMANO] ⚠️ Erro ao enviar: {e}", flush=True)
        return None


async def _postar_sala_iniciada(canal, user_ids_go=None):
    """Inicia a sala via API SalasBot (usando sshash salvo) e posta caixa estilizada
    mencionando os 2 usuários que deram GO. Delay humanoide antes pra não parecer
    instantâneo. Se a API falhar, ainda posta a caixa anunciando."""
    ch_id = str(canal.id)
    dados = _dados_sala_canal.get(ch_id) or {}
    sshash = dados.get('sshash', '')
    room_id = dados.get('roomId', '')
    # base_url salvo no momento da criação — usar o MESMO endpoint pra iniciar,
    # porque sshash é específico de quem criou. Se não foi salvo (cache antigo
    # de antes do patch), cai pra primária via default None.
    base_url_start = dados.get('base_url')

    # Delay humanoide curto pra parecer que tá "iniciando" manualmente
    try:
        await asyncio.sleep(random.uniform(1.5, 3.0))
    except Exception:
        pass

    # Tenta iniciar via API com retry de rate limit (máx 3 tentativas)
    api_ok = False
    if sshash:
        for tentativa in range(1, 4):
            resultado = await _iniciar_sala_api(sshash, room_id, base_url=base_url_start)
            if resultado.get('ok'):
                api_ok = True
                print(f"[{stamp()}] [GO] ✅ Sala iniciada via API (tentativa {tentativa}, roomId={room_id}).", flush=True)
                break
            if resultado.get('rate_limited'):
                retry_after = max(1, min(int(resultado.get('retry_after', 10)), 60))
                print(f"[{stamp()}] [GO] ⏳ Rate limit no start_room (tentativa {tentativa}/3). Aguardando {retry_after}s...", flush=True)
                await asyncio.sleep(retry_after + 1)
                continue
            # Erro permanente — sai do loop
            erro = resultado.get('msg_erro', 'erro desconhecido')
            print(f"[{stamp()}] [GO] ❌ Falha ao iniciar sala via API: {erro}", flush=True)
            break
    else:
        print(f"[{stamp()}] [GO] ⚠️ Sem sshash no canal — posto caixa mas não chamo API.", flush=True)

    # Posta caixa anunciando o início. Mention dos 2 vai ACIMA da caixa
    # (Discord não renderiza mention dentro de blocos de código/caixas).
    try:
        mention_str = ''
        if user_ids_go:
            mention_str = ' '.join(f'<@{uid}>' for uid in user_ids_go) + '\n'

        linhas = ["🎮  **SALA INICIADA**"]
        if api_ok:
            linhas.append("✅  Bom jogo a todos!")
        else:
            linhas.append("✅  Bom jogo!")
        caixa = _caixa_simples(linhas, largura=34)
        msg_completa = mention_str + caixa
        await _humano_typing_send(canal, msg_completa, min_delay=0.8, max_delay=1.8)
    except Exception as e:
        ch_nome = getattr(canal, 'name', '?')
        print(f"[{stamp()}] [GO] ❌ Erro ao postar 'Sala iniciada' em #{ch_nome}: {e}", flush=True)


# Helper para responder PG — replica message.reply quando há message original,
# senão envia mensagem nova no canal. Usado pelo OCR automático (sem message).
async def _responder_pg(message, canal, content, mention_author=False):
    if message is not None:
        try:
            return await message.reply(content, mention_author=mention_author)
        except Exception:
            # Fallback se reply falhar (msg apagada): manda no canal
            pass
    return await canal.send(content)


async def _buscar_e_responder_pg(message, canal, autor_id, autor_nome, consulta, termos, valor_minimo, modo_silencioso, ch_id, nome_ocr=None):
    """Núcleo da busca PG — extraído do on_message pra poder ser chamado tanto
    quando o cliente digita 'pg nome' (passa message do user) quanto quando o
    OCR detecta comprovante automaticamente (passa message=None — bot posta
    uma mensagem nova no canal mencionando o autor do comprovante).

    Faz tudo que o pg fazia: trava anti-duplicata por autor+canal, conexão IMAP
    com retry, resposta verbose/silenciosa, e incremento do contador de pgs
    pra criar sala automaticamente quando bater 2.

    Parâmetros:
      message: discord.Message original do `pg`, OU None se vier do OCR.
               Quando None, usa canal.send(); quando presente, usa message.reply().
      canal: discord.TextChannel (sempre presente)
      autor_id: int — pra (canal_id, autor_id) na trava _buscas_em_andamento
      autor_nome: str — pra logs
      consulta: nome completo a buscar (string limpa)
      termos: list[str] já normalizada (_norm) das palavras do nome
      valor_minimo: float ou None
      modo_silencioso: bool — não manda 'verificando...', só responde se achar 1 match
      ch_id: str id do canal
      nome_ocr: str ou None — nome COMPLETO lido do comprovante pelo OCR.
                Quando presente, é a fonte mais confiável do nome (leu o recibo
                inteiro), então tem prioridade na resposta de confirmação.
    """
    # ── Trava anti-duplicata: ignora se MESMO usuário já tem pg em andamento NESTE canal
    chave_busca = (ch_id, autor_id)
    if chave_busca in _buscas_em_andamento:
        print(f"[{stamp()}] [PG] ⏭️ {autor_nome} já tem busca em andamento neste canal — ignorando.", flush=True)
        return

    # Texto "bonito" do nome digitado (capitaliza) pra colocar nas respostas
    nome_bonito = ' '.join(p.capitalize() for p in consulta.split())

    def _caixa(linhas, largura=34):
        """Monta uma caixa com cantos arredondados pra exibir no Discord.
        A largura é só pra borda superior/inferior — Discord usa fonte proporcional
        então os emojis e textos não ficam alinhados perfeitamente, mas a caixa
        em si já dá um visual bonito."""
        borda_top = '╭' + ('─' * (largura - 2)) + '╮'
        borda_bot = '╰' + ('─' * (largura - 2)) + '╯'
        corpo = '\n'.join(f"│ {l}" for l in linhas)
        return f"{borda_top}\n{corpo}\n{borda_bot}"

    # ── Gmail desativado → resposta direta (com delay humano)
    if not GMAIL_USUARIO or not GMAIL_SENHA_IMAP:
        msg_err = _montar_msg_pg_nao_encontrado(nome_bonito, aviso_extra="Gmail não configurado")
        try:
            async with canal.typing():
                await asyncio.sleep(random.uniform(1.2, 2.8))
                await _responder_pg(message, canal, msg_err, mention_author=False)
        except Exception:
            pass
        print(f"[{stamp()}] [PG] ⚠️ Gmail desativado — respondido 'não encontrado'.", flush=True)
        return

    # ── Manda 'verificando...' (com delay humano + typing) e guarda referência da msg
    _buscas_em_andamento.add(chave_busca)
    try:
        # Janela de busca: 100 tentativas × 0.3s = 30s total. Busca IMAP a cada
        # 0.3s pra pegar o email no instante que chegar — quase instantâneo.
        # Reusa a mesma conexão IMAP a busca toda (login só 1 vez), então cada
        # tentativa custa só 1 SEARCH + N FETCH (rápido pra inbox limpa).
        TENTATIVAS = 100
        ESPERA = 0.3
        SEGUNDOS_TOTAIS = int(round(TENTATIVAS * ESPERA))  # 30

        # Caixa "verificando..." — montada respeitando STILO_CAIXA pra
        # ficar visualmente consistente com a resposta final.
        if STILO_CAIXA == 'mobile_estrela':
            _linhas_v = [
                "★  **Verificando pagamento...**",
                f"👤  {nome_bonito}",
                f"⏱️  aguarde até {SEGUNDOS_TOTAIS}s",
            ]
            _largura_v = 32
            _borda_v = '+' + ('─' * (_largura_v - 2)) + '+'
            _corpo_v = '\n'.join(f"  {l}" for l in _linhas_v)
            msg_verificando_inicial = f"{_borda_v}\n{_corpo_v}\n{_borda_v}"
        elif STILO_CAIXA == 'codeblock':
            _linhas_v = [
                "VERIFICANDO PAGAMENTO...",
                "",
                f"👤 {nome_bonito}",
                f"⏱️ aguarde até {SEGUNDOS_TOTAIS}s",
            ]
            _largura_v = 30
            _borda_v = '+' + ('─' * (_largura_v - 2)) + '+'
            _corpo_v = '\n'.join(f"| {l}" for l in _linhas_v)
            msg_verificando_inicial = f"```\n{_borda_v}\n{_corpo_v}\n{_borda_v}\n```"
        elif STILO_CAIXA == 'compacto':
            msg_verificando_inicial = (
                f"🔹  **Verificando pagamento...**\n"
                f"👤  {nome_bonito}\n"
                f"⏱️  aguarde até {SEGUNDOS_TOTAIS}s"
            )
        else:
            msg_verificando_inicial = _caixa([
                "🔹  **Verificando pagamento...**",
                f"👤  {nome_bonito}",
                f"⏱️  aguarde até {SEGUNDOS_TOTAIS}s",
            ])

        # Modo silencioso: não manda "verificando..." — só responde se achar 1 match
        msg_verif = None
        if not modo_silencioso:
            # Delay humano curto antes de enviar a primeira mensagem (era 1.2-2.8s, agora 0.4-0.8s)
            async with canal.typing():
                await asyncio.sleep(random.uniform(0.4, 0.8))
                try:
                    msg_verif = await _responder_pg(message, canal, msg_verificando_inicial, mention_author=False)
                except Exception as e:
                    print(f"[{stamp()}] [PG] erro ao enviar 'verificando': {e}", flush=True)
                    return

        # ── Retry: 100 tentativas, 0.3s entre cada. Reusa conexão IMAP (1 login só).
        resultados = []
        m_imap = None
        t_inicio = time.time()
        try:
            try:
                t_conn = time.time()
                m_imap = await _conectar_imap_async()
                print(f"[{stamp()}] [PG] 🔌 IMAP conectado em {time.time() - t_conn:.1f}s", flush=True)
            except Exception as e:
                print(f"[{stamp()}] [PG] ❌ Falha ao conectar IMAP: {e}", flush=True)
                m_imap = None

            for tentativa in range(1, TENTATIVAS + 1):
                t_tent = time.time()
                try:
                    if m_imap is None:
                        # Reconecta se a conexão caiu
                        m_imap = await _conectar_imap_async()
                    resultados = await _buscar_em_conexao_async(m_imap, (termos, valor_minimo), 50, 2)
                except Exception as e:
                    print(f"[{stamp()}] [PG] ❌ Erro IMAP (tentativa {tentativa}/{TENTATIVAS}): {e}", flush=True)
                    # Conexão pode ter morrido — fecha e força reconexão na próxima
                    if m_imap:
                        _imap_logout_silencioso(m_imap)
                    m_imap = None
                    resultados = []

                dur = time.time() - t_tent
                if resultados:
                    print(f"[{stamp()}] [PG] ✅ Achou na tentativa {tentativa}/{TENTATIVAS} ({dur:.1f}s).", flush=True)
                    break

                if tentativa < TENTATIVAS:
                    # Loga só a cada 10 tentativas (~3s) pra não floodar o painel-cliente.
                    # Sempre loga a 1ª e a última também.
                    if tentativa == 1 or tentativa % 10 == 0:
                        print(f"[{stamp()}] [PG] ⏳ Tentativa {tentativa}/{TENTATIVAS} sem match ({dur:.2f}s). Aguardando {ESPERA}s.", flush=True)
                    await asyncio.sleep(ESPERA)
        finally:
            if m_imap:
                _imap_logout_silencioso(m_imap)
            print(f"[{stamp()}] [PG] 🏁 Busca total: {time.time() - t_inicio:.1f}s", flush=True)

        # ── Monta resposta final bonita
        if resultados:
            primeiro = resultados[0]
            valor_email = primeiro.get('valor')
            valor_fmt = f"R$ {valor_email:.2f}".replace('.', ',') if valor_email is not None else "—"
            banco_fmt = primeiro.get('banco', '?').upper()
            # Nome a mostrar. Prioridade:
            #  1º nome_ocr — lido do comprovante (recibo inteiro), mais confiável
            #  2º nome_pagador — extraído do CORPO do email do banco
            #  3º nome_bonito — o que foi digitado no 'pg'
            # Nunca cai pro display do From (header) porque ali vem "Inter",
            # "Nubank", "Picpay" — o NOME DO BANCO, não do pagador.
            remetente_real = (
                (nome_ocr or '').strip()
                or primeiro.get('nome_pagador')
                or nome_bonito
                or '(nome não identificado)'
            )
            valor_ok = primeiro.get('valor_ok', True)
            v_min = primeiro.get('valor_minimo')

            linhas_resp = [
                "✅  **Pagamento confirmado**",
                f"👤  {remetente_real}",
                f"🏦  Banco: **{banco_fmt}**",
            ]
            if MOSTRAR_VALOR_PAGAMENTO:
                linhas_resp.append(f"💵  {valor_fmt}")
            # Se o valor não bateu o mínimo esperado, avisa mas confirma mesmo assim
            if not valor_ok and v_min is not None:
                v_min_fmt = f"R$ {v_min:.2f}".replace('.', ',')
                linhas_resp.append(f"⚠️  valor abaixo do esperado ({v_min_fmt})")
            # Usa o builder por estilo (STILO_CAIXA); a `linhas_resp` acima é
            # mantida só pra log/debug — a mensagem que vai pro Discord sai do
            # _montar_msg_pagamento que aplica o visual escolhido pelo cliente.
            resposta_final = _montar_msg_pagamento(
                remetente=remetente_real,
                banco=banco_fmt,
                valor_fmt=valor_fmt if MOSTRAR_VALOR_PAGAMENTO else None,
                valor_ok=valor_ok,
                v_min=v_min,
            )
        else:
            resposta_final = _montar_msg_pg_nao_encontrado(nome_bonito)

        # ═════════════════════════════════════════════════════════════
        # Contabiliza o pg confirmado e cria sala ao bater 2.
        # Extraído numa função pra ser chamado TANTO pelo modo silencioso
        # (comprovante/OCR) QUANTO pelo modo normal ('pg nome' digitado).
        # Antes só o modo normal contava — comprovante confirmava mas não
        # incrementava o contador, então '1 pg + 1 comprovante' nunca criava sala.
        # ═════════════════════════════════════════════════════════════
        def _contabilizar_e_criar_sala():
            if not (resultados and ch_id not in _sala_criada_canal):
                return
            atual = _pgs_confirmados_por_canal.get(ch_id, 0) + 1
            _pgs_confirmados_por_canal[ch_id] = atual
            ch_nome_sala = getattr(canal, 'name', '?')
            print(f"[{stamp()}] [SALA] 📊 #{ch_nome_sala}: {atual}/2 pgs confirmados.", flush=True)

            if atual >= 2:
                # Decide modo. Prioridade:
                # 1) Apelido detectado em mensagem do canal (mais específico)
                # 2) Apelido detectado no NOME do canal (ex: "1v1 Gel Infinito")
                # 3) MODO_PADRAO do cliente
                # 4) Modo 1 como último recurso (sem carregamento) — evita morrer silencioso
                modo_canal = _modo_por_canal.get(ch_id)
                modo_nome = None
                if not modo_canal:
                    modo_nome = _detectar_modo_pelo_nome_canal(canal)

                modo_usado = modo_canal or modo_nome or MODO_PADRAO

                origem = None
                if modo_canal:
                    origem = "apelido em mensagem"
                elif modo_nome:
                    origem = f"apelido no nome do canal ('{getattr(canal, 'name', '?')}')"
                    # Trava também pra evitar re-detectar à toa
                    _modo_por_canal[ch_id] = modo_nome
                elif MODO_PADRAO in (1, 2, 3, 4, 5):
                    origem = "padrão do cliente"

                # Fallback final: usa modo 1 se ainda não tem modo válido.
                # Evita o bug antigo de "2 pgs OK mas sala não criada".
                if modo_usado not in (1, 2, 3, 4, 5):
                    modo_usado = 1
                    origem = "fallback (sem apelido e sem MODO_PADRAO — usando modo 1)"
                    print(f"[{stamp()}] [SALA] ⚠️ #{ch_nome_sala}: 2 pgs OK mas sem modo configurado. "
                          f"Usando modo 1 como fallback. Configure MODO_PADRAO no painel pra evitar isso.", flush=True)

                print(f"[{stamp()}] [SALA] 🛠️ Disparando criação de sala (modo {modo_usado}, origem: {origem})...", flush=True)
                _sala_criada_canal.add(ch_id)  # trava ANTES de chamar pra evitar corrida
                # Roda em background pra não segurar o on_message — assim o rate limit retry
                # não bloqueia outras mensagens chegando no bot.
                client.loop.create_task(
                    _criar_sala_com_retry(canal, modo_usado, ch_nome_sala, ch_id)
                )

        # ═════════════════════════════════════════════════════════════
        # MODO SILENCIOSO (1 palavra / OCR) — regras especiais de resposta:
        #   - 0 matches  → não responde nada (silêncio total)
        #   - 1 match    → responde normalmente (msg nova já que não tem msg_verif)
        #   - 2+ matches → não responde nada (cliente confirma manual)
        # IMPORTANTE: contabiliza o pg ANTES do return — senão comprovante
        # confirma mas não conta pra criar sala.
        # ═════════════════════════════════════════════════════════════
        if modo_silencioso:
            qtd = len(resultados)
            if qtd == 1:
                print(f"[{stamp()}] [PG] 🤫✅ Modo silencioso achou 1 match único — respondendo no chat.", flush=True)
                try:
                    await _responder_pg(message, canal, resposta_final, mention_author=False)
                except Exception as e:
                    print(f"[{stamp()}] [PG] ❌ Falha ao enviar reply silencioso ({type(e).__name__}: {e}).", flush=True)
            elif qtd == 0:
                print(f"[{stamp()}] [PG] 🤫🚫 Modo silencioso: 0 matches — não respondendo no chat.", flush=True)
            else:
                print(f"[{stamp()}] [PG] 🤫⚠️ Modo silencioso: {qtd} matches ambíguos — não respondendo no chat (admin decide manual).", flush=True)
                # Loga os matches pro admin ver no painel-cliente
                for i, r in enumerate(resultados, 1):
                    vfmt = f"R$ {r['valor']:.2f}" if r.get('valor') is not None else "?"
                    rname = r['remetente'] or f"(banco:{r.get('remetente_raw_from','?')})"
                    print(f"[{stamp()}] [PG]    cand {i}: [{r['banco']}] {rname} — {vfmt}", flush=True)
            # Conta o pg mesmo no modo silencioso. Só conta se achou match
            # ÚNICO (qtd == 1) — 0 ou 2+ não confirma pagamento, então não conta.
            if qtd == 1:
                _contabilizar_e_criar_sala()
            return

        # === MODO NORMAL (2+ palavras) — sempre responde, editando msg_verif ===
        # Edita a resposta final IMEDIATAMENTE — não dá pra deixar o admin esperando.
        # Se o edit falhar (msg apagada, sem permissão), tenta uma mensagem nova como fallback.
        try:
            await msg_verif.edit(content=resposta_final)
            print(f"[{stamp()}] [PG] ✏️ Resposta final editada em msg {msg_verif.id}.", flush=True)
        except Exception as e:
            print(f"[{stamp()}] [PG] ⚠️ erro ao editar resposta final ({type(e).__name__}: {e}) — tentando msg nova.", flush=True)
            try:
                await _responder_pg(message, canal, resposta_final, mention_author=False)
                print(f"[{stamp()}] [PG] ✏️ Resposta final enviada como reply (fallback).", flush=True)
            except Exception as e2:
                print(f"[{stamp()}] [PG] ❌ FALHOU também o reply de fallback ({type(e2).__name__}: {e2}). Resposta perdida!", flush=True)

        # ── Detalhes só nos logs do Discloud (admin vê)
        if resultados:
            print(f"[{stamp()}] [PG] ✅ {len(resultados)} match(es) pra '{consulta}' (min R$ {valor_minimo}):", flush=True)
            for i, r in enumerate(resultados, 1):
                vfmt = f"R$ {r['valor']:.2f}" if r.get('valor') is not None else "?"
                rname = r['remetente'] or f"(banco:{r.get('remetente_raw_from','?')})"
                print(f"[{stamp()}] [PG]    {i}. [{r['banco']}] {rname} <{r['endereco']}> — {vfmt} — {r['data']}", flush=True)
                print(f"[{stamp()}] [PG]       └─ {r['assunto'][:120]}", flush=True)
        else:
            print(f"[{stamp()}] [PG] 🚫 Nenhum match após {TENTATIVAS} tentativas (mín R$ {valor_minimo}).", flush=True)

        # Contabiliza o pg confirmado e cria sala ao bater 2 (modo normal).
        _contabilizar_e_criar_sala()

    finally:
        _buscas_em_andamento.discard(chave_busca)


@client.event
async def on_message(message):
    # Selfbot ignora mensagens próprias pra não loopar
    if message.author.id == client.user.id:
        return

    # Trava anti-duplicata: o gateway às vezes entrega a mesma msg 2x
    msg_id = message.id
    if msg_id in _msgs_processadas_set:
        return
    _msgs_processadas.append(msg_id)
    _msgs_processadas_set.add(msg_id)
    # Limpa do set quando sair do deque (deque já capou em 500)
    if len(_msgs_processadas_set) > len(_msgs_processadas):
        # rebuild simples — só roda raramente
        _msgs_processadas_set.intersection_update(set(_msgs_processadas))

    conteudo = (message.content or '').strip()

    # Texto completo incluindo embeds — necessário pra mensagens de bots
    # (Whale Apostas, etc) que postam conteúdo via embed, com content vazio.
    # Usado pelo gate de ativação E pela detecção de PIX_AUTO logo abaixo.
    texto_msg_completo = _texto_completo_msg(message)

    # Pré-computa versão normalizada UMA VEZ por mensagem (compartilhada entre
    # gate de ativação e detecção PIX_AUTO). Normalização tira pontos, traços
    # e espaços — chave salva como "54469356832" bate com "544.693.568-32"
    # postado no chat. Sem isso, formato visual quebra a detecção.
    _pix_key_norm = _normalizar_pix(PIX_KEY) if PIX_KEY else ''
    _texto_msg_norm = _normalizar_pix(texto_msg_completo) if texto_msg_completo else ''

    # DUAS estratégias de match — basta uma funcionar pra disparar.
    # 1) Match NORMALIZADO: ignora pontos/traços/espaços/símbolos.
    #    Cobre 99% dos casos.
    # 2) Match LITERAL: chave exatamente como o cliente salvou.
    #    Útil se o cliente salvou com formatação específica que ele quer manter
    #    intacta (ex: salvou ` `544.693.568-32` ` com backticks porque é assim
    #    que ele cola), ou caso edge onde a normalização não bate.
    _pix_match_norm = bool(_pix_key_norm and _texto_msg_norm and _pix_key_norm in _texto_msg_norm)
    _pix_match_literal = bool(PIX_KEY and texto_msg_completo and PIX_KEY in texto_msg_completo)
    _pix_detectado = _pix_match_norm or _pix_match_literal

    # === DEBUG PIX: loga quando uma msg em canal monitorado chega com
    # PINTA DE COBRANÇA PIX (tem palavras-chave) mas a chave NÃO foi detectada.
    # Antes só logava pra msgs de BOT — mas chave PIX postada por PESSOA
    # (cliente/admin colando manual) também falha sem aviso. Agora cobre ambos.
    # Filtra por palavras-chave pra não floodar com msgs aleatórias.
    if PIX_KEY and not _pix_detectado and texto_msg_completo:
        # Heurística: msg parece cobrança PIX? Tem "chave", "pix" ou "pagar"
        # E tem algum padrão de chave (CPF/telefone/aleatória/email)
        import re as _re_dbg
        texto_lower = texto_msg_completo.lower()
        tem_palavra_pix = any(p in texto_lower for p in ('chave', 'pix', 'pagar', 'valor a'))
        tem_padrao_chave = bool(_re_dbg.search(r'\d{3}\.?\d{3}\.?\d{3}-?\d{2}|\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}|[\w.-]+@[\w.-]+|[0-9a-f]{8}-[0-9a-f]{4}|\d{10,11}', texto_msg_completo))

        if tem_palavra_pix and tem_padrao_chave:
            ch_id_dbg = str(message.channel.id)
            parent_id_dbg = str(getattr(message.channel, 'parent_id', '') or '')
            cat_obj_dbg = getattr(message.channel, 'category', None)
            cat_id_dbg = str(getattr(cat_obj_dbg, 'id', '') or '')
            monit_dbg = set(FORUM_CHANNEL_IDS); monit_dbg.update(CATEGORIA_IDS)
            if ch_id_dbg in monit_dbg or parent_id_dbg in monit_dbg or cat_id_dbg in monit_dbg:
                ch_nome_dbg = getattr(message.channel, 'name', '?')
                autor_dbg = getattr(message.author, 'name', '?')
                preview_texto = (texto_msg_completo or '')[:300].replace('\n', ' ')

                # Detecta se o que está no canal PARECE com nossa chave
                # (mesmo se o match falhou). Útil pra detectar bugs onde a chave
                # do cliente ESTÁ na msg mas algo na comparação dá errado.
                # Extrai todos os possíveis "candidatos a chave" do texto
                candidatos = _re_dbg.findall(
                    r'\d{3}\.?\d{3}\.?\d{3}-?\d{2}|\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}|[\w.-]+@[\w.-]+|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|\d{10,11}',
                    texto_msg_completo
                )
                candidatos_norm = [_normalizar_pix(c) for c in candidatos]
                possivel_nossa_chave = _pix_key_norm and _pix_key_norm in candidatos_norm

                if possivel_nossa_chave:
                    # NOSSA chave está no texto mas a comparação falhou — BUG!
                    print(f"[{stamp()}] [PIX-BUG] ⚠️ #{ch_nome_dbg}: NOSSA CHAVE detectada no texto mas comparação falhou!", flush=True)
                    print(f"[{stamp()}] [PIX-BUG]   PIX_KEY raw   : {PIX_KEY!r}", flush=True)
                    print(f"[{stamp()}] [PIX-BUG]   PIX_KEY norm  : {_pix_key_norm!r}", flush=True)
                    print(f"[{stamp()}] [PIX-BUG]   texto norm    : {_texto_msg_norm!r}", flush=True)
                    print(f"[{stamp()}] [PIX-BUG]   match_norm    : {_pix_match_norm}", flush=True)
                    print(f"[{stamp()}] [PIX-BUG]   match_literal : {_pix_match_literal}", flush=True)
                    print(f"[{stamp()}] [PIX-BUG]   candidatos    : {candidatos}", flush=True)
                    print(f"[{stamp()}] [PIX-BUG]   candidatos_n  : {candidatos_norm}", flush=True)
                else:
                    # Chave de outro admin no mesmo servidor — comportamento normal.
                    print(f"[{stamp()}] [PIX-INFO] #{ch_nome_dbg}: PIX de '{autor_dbg}' (outro admin, não é nossa chave).", flush=True)
                    print(f"[{stamp()}] [PIX-INFO]   minha chave: {PIX_KEY[:20]}... (norm: {_pix_key_norm})", flush=True)
                    print(f"[{stamp()}] [PIX-INFO]   chave no canal: {candidatos[:3]}", flush=True)

    # ═════════════════════════════════════════════════════════════
    # GATE DE ATIVAÇÃO POR CANAL (modo PIX_AUTO_ATIVO)
    # ═════════════════════════════════════════════════════════════
    # Se PIX_AUTO_ATIVO=True, o bot só atua num canal DEPOIS de ver a
    # chave PIX postada lá. Detecta aqui no início e marca o canal como
    # ativado pra que os blocos seguintes (PG, GO, apelidos, comprovantes,
    # PIX_AUTO resposta, etc) tomem conhecimento.
    #
    # Função helper `_canal_pode_agir(message)`:
    #   - Se PIX_AUTO_ATIVO=False → True sempre (modo legado, bot age em tudo)
    #   - Se PIX_AUTO_ATIVO=True  → True só se o canal está em _canais_ativados
    if PIX_AUTO_ATIVO and _pix_detectado:
        ch_id_chk = str(message.channel.id)
        parent_id_chk = str(getattr(message.channel, 'parent_id', '') or '')
        cat_obj_chk = getattr(message.channel, 'category', None)
        cat_id_chk = str(getattr(cat_obj_chk, 'id', '') or '')
        monit_chk = set(FORUM_CHANNEL_IDS)
        monit_chk.update(CATEGORIA_IDS)
        canal_eh_monitorado = (
            ch_id_chk in monit_chk or
            parent_id_chk in monit_chk or
            cat_id_chk in monit_chk
        )
        if canal_eh_monitorado and ch_id_chk not in _canais_ativados:
            _canais_ativados.add(ch_id_chk)
            ch_nome_act = getattr(message.channel, 'name', '?')
            autor_act = getattr(message.author, 'name', '?')
            print(f"[{stamp()}] [ATIVAR] 🔓 #{ch_nome_act} ativado por '{autor_act}' (chave PIX detectada). "
                  f"Agora bot processa PG/GO/comprovantes neste canal.", flush=True)

    # ═════════════════════════════════════════════════════════════
    # OCR DE COMPROVANTES — se a msg tem anexo de imagem em canal monitorado,
    # processa em background pra extrair nome+valor (usado depois no "pg").
    # Só roda em canais monitorados, pra economizar OCR.space.
    # ═════════════════════════════════════════════════════════════
    if message.attachments:
        ch_id_img = str(message.channel.id)
        parent_id_img = str(getattr(message.channel, 'parent_id', '') or '')
        cat_obj_img = getattr(message.channel, 'category', None)
        cat_id_img = str(getattr(cat_obj_img, 'id', '') or '')
        monit_img = set(FORUM_CHANNEL_IDS)
        monit_img.update(CATEGORIA_IDS)
        if ch_id_img in monit_img or parent_id_img in monit_img or cat_id_img in monit_img:
            # Gate PIX_AUTO_ATIVO: pula processamento de comprovante se o canal
            # ainda não foi ativado pela chave PIX. Comprovante antes da chave
            # é fora da rotina de venda — provavelmente lixo, ignora.
            if _canal_pode_agir(message):
                for att in message.attachments:
                    ct = (getattr(att, 'content_type', '') or '').lower()
                    fn = (getattr(att, 'filename', '') or '').lower()
                    eh_imagem = (
                        ct.startswith('image/') or
                        any(fn.endswith(ext) for ext in ('.png', '.jpg', '.jpeg', '.webp', '.gif'))
                    )
                    if eh_imagem:
                        # Roda em background — não trava o on_message.
                        # Passa a message inteira pra função poder mencionar quem postou
                        # quando o OCR for usado pra confirmação automática.
                        client.loop.create_task(_processar_comprovante_async(message, att))
                        break  # só processa 1 anexo por msg pra evitar gastar OCR à toa

    # ═════════════════════════════════════════════════════════════
    # DETECÇÃO DE "GO" — quando 2 pessoas mandam "go" no canal, posta caixa
    # "Sala iniciada". 1x por canal por execução. Só roda em canais monitorados,
    # só conta após a sala ter sido criada (faz sentido cronológico).
    # ═════════════════════════════════════════════════════════════
    if conteudo:
        ch_id_atual = str(message.channel.id)
        # Match exato de "go" como token isolado (ignorando pontuação)
        # Aceita: "go", "Go", "GO", "go!", "go.", "go, vamos", "vamos go"
        tokens_lower = [t.lower().strip('!?.,:;') for t in conteudo.split()]
        tem_go = 'go' in tokens_lower

        tem_go_em_sala_iniciada = tem_go and ch_id_atual in _sala_iniciada_canal
        if tem_go_em_sala_iniciada:
            # Canal já marcou sala como iniciada. Provavelmente reutilizado pra nova venda
            # mas o fluxo de criar-sala-de-novo já deveria ter limpado essa flag. Se
            # cair aqui, alguma coisa está fora de ordem. Log pra investigar.
            ch_nome_dbg = getattr(message.channel, 'name', '?')
            autor_dbg = getattr(message.author, 'name', '?')
            print(f"[{stamp()}] [GO-BLOCK] ⚠️ #{ch_nome_dbg}: '{autor_dbg}' mandou go mas canal está em _sala_iniciada_canal. "
                  f"sala_criada={ch_id_atual in _sala_criada_canal}, "
                  f"pgs={_pgs_confirmados_por_canal.get(ch_id_atual, 0)}, "
                  f"dados_sala={'sim' if ch_id_atual in _dados_sala_canal else 'não'}", flush=True)

        if tem_go and ch_id_atual not in _sala_iniciada_canal:
            parent_id_go = str(getattr(message.channel, 'parent_id', '') or '')
            cat_obj_go = getattr(message.channel, 'category', None)
            cat_id_go = str(getattr(cat_obj_go, 'id', '') or '')
            monit_go = set(FORUM_CHANNEL_IDS)
            monit_go.update(CATEGORIA_IDS)
            if ch_id_atual in monit_go or parent_id_go in monit_go or cat_id_go in monit_go:
                # Gate PIX_AUTO_ATIVO: canal precisa ter visto a chave PIX antes.
                # `_canal_pode_agir` retorna True direto se PIX_AUTO_ATIVO=False
                # (modo legado). Se gate fechado, pula tudo silenciosamente.
                _go_gate_ok = _canal_pode_agir(message)
                # Exigência cronológica: GO só faz sentido SE a sala já foi criada.
                # Duas formas de saber que tem sala:
                #   a) `_sala_criada_canal` — sala criada NESTA execução do bot
                #   b) `tem_sshash` em _dados_sala_canal — sshash em cache (sala
                #      criada em execução anterior, cache persiste em disco)
                # Se nenhuma das duas, ignora — provavelmente é canal sem venda
                # ainda ou alguém testando "go" antes da hora.
                tem_sshash_cache = 'sshash' in (_dados_sala_canal.get(ch_id_atual) or {})
                sala_existe = (ch_id_atual in _sala_criada_canal) or tem_sshash_cache

                if not _go_gate_ok:
                    pass  # gate PIX fechado — ignora silencioso
                elif not sala_existe:
                    # Log silencioso só pra debug — sem spam no log de produção.
                    # Comente o print abaixo se quiser zerar ruído.
                    autor_nome_skip = getattr(message.author, 'name', '?')
                    ch_nome_skip = getattr(message.channel, 'name', '?')
                    print(f"[{stamp()}] [GO-SKIP] #{ch_nome_skip}: '{autor_nome_skip}' mandou go mas sala ainda não foi criada. Ignorando.", flush=True)
                else:
                    autor_id_go = message.author.id
                    autor_nome_go = getattr(message.author, 'name', '?')
                    ch_nome_go = getattr(message.channel, 'name', '?')
                    gos = _gos_por_canal.setdefault(ch_id_atual, set())

                    # Log diagnóstico SEMPRE — ajuda a entender por que o GO às vezes
                    # não dispara. Mostra estado completo no momento do recebimento.
                    ja_tinha = autor_id_go in gos
                    print(f"[{stamp()}] [GO-DEBUG] #{ch_nome_go} msg_id={message.id} "
                          f"autor='{autor_nome_go}' (id={autor_id_go}) ja_contou={ja_tinha} "
                          f"gos_antes={len(gos)} usuarios={list(gos)} "
                          f"sala_iniciada={ch_id_atual in _sala_iniciada_canal} "
                          f"sala_criada={ch_id_atual in _sala_criada_canal} "
                          f"tem_sshash={tem_sshash_cache}", flush=True)

                    if autor_id_go not in gos:
                        gos.add(autor_id_go)
                        print(f"[{stamp()}] [GO] 🟢 #{ch_nome_go}: '{autor_nome_go}' mandou go ({len(gos)}/2).", flush=True)

                        # Reage com ✅ na mensagem de quem mandou go — feedback visual rápido.
                        # Pequeno delay humano antes da reação (não é instantâneo).
                        async def _reagir_go(msg):
                            try:
                                await asyncio.sleep(random.uniform(0.5, 1.5))
                                await msg.add_reaction('✅')
                            except Exception as e:
                                print(f"[{stamp()}] [GO] ⚠️ Erro ao reagir: {e}", flush=True)
                        client.loop.create_task(_reagir_go(message))

                        if len(gos) >= 2:
                            _sala_iniciada_canal.add(ch_id_atual)
                            # Captura os 2 user_ids que deram go pra mencionar na caixa
                            user_ids_go = list(gos)
                            print(f"[{stamp()}] [GO] 🎮 #{ch_nome_go}: 2 GOs → iniciando sala via API + postando caixa (mencionando {user_ids_go}).", flush=True)
                            client.loop.create_task(_postar_sala_iniciada(message.channel, user_ids_go))

    # ═════════════════════════════════════════════════════════════
    # DETECÇÃO DE APELIDO → define modo do canal (1ª msg trava)
    # Procura nas mensagens de qualquer usuário (incluindo bots) em canais monitorados,
    # tokens isolados que casam com algum apelido cadastrado. Também olha o nome
    # do canal (ex: "1v1 Gel Infinito | Mobile" → 'gel' bate apelido). Só registra
    # o PRIMEIRO match por canal por execução do bot — depois fica travado.
    # ═════════════════════════════════════════════════════════════
    if _apelidos_modo:
        ch_id_ap = str(message.channel.id)
        if ch_id_ap not in _modo_por_canal:
            parent_id_ap = str(getattr(message.channel, 'parent_id', '') or '')
            cat_obj_ap = getattr(message.channel, 'category', None)
            cat_id_ap = str(getattr(cat_obj_ap, 'id', '') or '')
            monit_ap = set(FORUM_CHANNEL_IDS)
            monit_ap.update(CATEGORIA_IDS)
            if ch_id_ap in monit_ap or parent_id_ap in monit_ap or cat_id_ap in monit_ap:
                # Gate PIX_AUTO_ATIVO: precisa do canal ativado pela chave PIX.
                # Sem gate, qualquer canal vazio onde alguém menciona 'gel' já
                # travaria o modo — desperdiçando a 1ª detecção.
                if not _canal_pode_agir(message):
                    pass  # gate fechado — pula apelido também
                else:
                    # 1) Tenta detectar pelo TEXTO COMPLETO (content + embeds).
                    # IMPORTANTE: usa texto_msg_completo, não só `conteudo` — mensagens
                    # de bots de aposta (ORG WURF, Whale, etc) postam o modo via embed
                    # com message.content vazio. Antes o bot só lia `conteudo` e perdia
                    # o "Gelo Infinito" que estava dentro do embed → criava sala modo 1.
                    #
                    # ESTRATÉGIA: escaneia TODOS os tokens, monta lista de candidatos
                    # e escolhe o mais ESPECÍFICO (apelido mais longo). Antes era
                    # first-match-wins, então numa msg tipo "1x1 Mobile Gelo Infinito"
                    # com apelidos {1x1:1, infinito:3}, casava "1x1" primeiro e parava
                    # → criava sala normal em vez de gel infinito. Agora pega o mais
                    # longo ("infinito" > "1x1") porque apelidos compostos/específicos
                    # devem ter prioridade sobre tokens genéricos.
                    modo_det = None
                    tok_det = None
                    texto_busca = texto_msg_completo or conteudo
                    if texto_busca:
                        texto_norm = _norm(texto_busca)
                        tokens = re.split(r'[\s.,;:!?/\\|()\[\]{}\-_*"\'`]+', texto_norm)
                        candidatos = []  # [(tok, modo)]
                        for tok in tokens:
                            if tok and tok in _apelidos_modo:
                                candidatos.append((tok, _apelidos_modo[tok]))
                        if candidatos:
                            # Pega o apelido mais longo (mais específico). Empate → primeiro.
                            candidatos.sort(key=lambda x: -len(x[0]))
                            tok_det, modo_det = candidatos[0]
                            if len(candidatos) > 1:
                                outros = ', '.join(f"'{c[0]}'→{c[1]}" for c in candidatos[1:])
                                print(f"[{stamp()}] [APELIDO] 🔎 múltiplos apelidos casaram, "
                                      f"escolhi mais específico '{tok_det}' (modo {modo_det}). Outros: {outros}", flush=True)

                    # 2) Fallback: tenta pelo NOME do canal (ex: "1v1 Gel Infinito | Mobile")
                    # Útil quando o cliente nomeia o canal com o modo e nunca menciona em texto.
                    if modo_det is None:
                        modo_det = _detectar_modo_pelo_nome_canal(message.channel)
                        if modo_det:
                            tok_det = f"nome canal"

                    if modo_det:
                        _modo_por_canal[ch_id_ap] = modo_det
                        ch_nome_ap = getattr(message.channel, 'name', '?')
                        print(f"[{stamp()}] [APELIDO] 🎮 #{ch_nome_ap}: '{tok_det}' → modo {modo_det} (1ª detecção, travada pro canal)", flush=True)

    # ═════════════════════════════════════════════════════════════
    # DETECÇÃO DE PIX → envia MENSAGEM_AUTO automaticamente
    # (sala NÃO é criada aqui — é criada após os 2 pgs confirmados)
    #
    # IMPORTANTE: Esta resposta acontece SEMPRE que detectar a chave,
    # mesmo com PIX_AUTO_ATIVO=False. O toggle só controla os outros
    # blocos reativos (PG, GO, comprovantes). Resposta automática é
    # cortesia básica — sempre manda quando alguém posta a chave.
    #
    # Usa _pix_detectado (já calculado no topo com normalização) — detecta
    # mesmo com formatação Discord (**negrito**, ``code``, etc) e chave salva
    # com formato diferente do postado (54469356832 vs 544.693.568-32).
    # ═════════════════════════════════════════════════════════════
    if MENSAGEM_AUTO and _pix_detectado:
        ch_id = str(message.channel.id)
        parent_id = str(getattr(message.channel, 'parent_id', '') or '')
        cat_obj = getattr(message.channel, 'category', None)
        cat_id = str(getattr(cat_obj, 'id', '') or '')
        monitorados = set(FORUM_CHANNEL_IDS)
        monitorados.update(CATEGORIA_IDS)

        if ch_id in monitorados or parent_id in monitorados or cat_id in monitorados:
            # Trava anti-spam: 1x por canal por execução do bot
            if ch_id in _canais_ja_respondidos:
                print(f"[{stamp()}] [PIX] ⏭️ Chave detectada em #{getattr(message.channel, 'name', '?')} mas canal já respondido. Ignorando.", flush=True)
            else:
                _canais_ja_respondidos.add(ch_id)
                autor_nome = getattr(message.author, 'name', '?')
                ch_nome = getattr(message.channel, 'name', '?')
                print(f"[{stamp()}] [PIX] 💰 Chave detectada em #{ch_nome} (postado por {autor_nome}). Enviando MENSAGEM_AUTO...", flush=True)
                try:
                    arquivo = await _preparar_imagem_auto()
                    if arquivo:
                        await _humano_typing_send(message.channel, MENSAGEM_AUTO, file=arquivo, min_delay=1.0, max_delay=2.5)
                        print(f"[{stamp()}] [PIX] ✅ MENSAGEM_AUTO + imagem enviada em #{ch_nome}.", flush=True)
                    else:
                        await _humano_typing_send(message.channel, MENSAGEM_AUTO, min_delay=1.0, max_delay=2.5)
                        print(f"[{stamp()}] [PIX] ✅ MENSAGEM_AUTO enviada em #{ch_nome} (sem imagem).", flush=True)
                except Exception as e:
                    # Se falhou, libera a trava pra tentar de novo na próxima
                    _canais_ja_respondidos.discard(ch_id)
                    print(f"[{stamp()}] [PIX] ❌ Erro ao enviar MENSAGEM_AUTO em #{ch_nome}: {e}", flush=True)
            # Não dá return aqui — a mesma msg pode também ter um comando 'pg'

    if not conteudo:
        # Mesmo sem texto, mensagens de bot podem ter embed com valor — checa antes de sair
        if not getattr(message.author, 'bot', False):
            return

    # ═════════════════════════════════════════════════════════════
    # Captura valor da sala a partir de mensagens de BOTS no canal
    # (usa `texto_msg_completo` que já tem content+embeds — não duplica trabalho)
    # ═════════════════════════════════════════════════════════════
    if getattr(message.author, 'bot', False) and _canal_pode_agir(message):
        match = _RE_VALOR_BR.search(texto_msg_completo)
        if match:
            valor = _valor_str_to_float(match.group(1))
            if valor is not None and valor > 0:
                ch_id_str = str(message.channel.id)
                anterior = _valor_por_canal.get(ch_id_str)
                _valor_por_canal[ch_id_str] = valor
                ch_nome = getattr(message.channel, 'name', '?')
                if anterior != valor:
                    print(f"[{stamp()}] [VALOR] 💵 #{ch_nome}: R$ {valor:.2f} (bot {getattr(message.author, 'name', '?')})", flush=True)

    if not conteudo:
        return

    # ─── Detecta gatilho 'pg' ou 'pago' no INÍCIO ou no FIM ───
    # Tokeniza preservando ordem
    tokens = conteudo.split()
    if not tokens:
        return

    GATILHOS = {'pg', 'pago'}
    primeiro = tokens[0].lower().rstrip('!?.,:;')
    ultimo = tokens[-1].lower().rstrip('!?.,:;')

    # Caso especial: msg é só "pg" ou "pago" sozinho — vamos tentar OCR depois
    if len(tokens) == 1:
        if primeiro not in GATILHOS:
            return
        resto = []
    elif primeiro in GATILHOS:
        # gatilho no início — pega o resto
        resto = tokens[1:]
    elif ultimo in GATILHOS:
        # gatilho no fim — pega tudo menos o último
        resto = tokens[:-1]
    else:
        return  # nem início nem fim — ignora

    # ─── Filtra tokens que parecem valor/número (0,50 / R$1 / 1.00 / tanto) ───
    # Regra: qualquer token que CONTÉM dígito é descartado, e o literal "tanto".
    # Também filtra símbolos de moeda soltos.
    def _eh_valor(tok):
        t = tok.lower().rstrip('!?.,:;').lstrip('!?.,:;')
        if not t:
            return True
        if t == 'tanto':
            return True
        if t in ('r$', 'rs', '$'):
            return True
        # contém dígito em qualquer lugar (cobre 0,50 / 1.00 / R$5 / 100)
        if any(c.isdigit() for c in t):
            return True
        return False

    palavras_nome = [t for t in resto if not _eh_valor(t)]
    consulta = ' '.join(palavras_nome).strip()

    # Detecta IDs do contexto da mensagem
    ch_id = str(message.channel.id)
    parent_id = str(getattr(message.channel, 'parent_id', '') or '')
    cat_obj = getattr(message.channel, 'category', None)
    cat_id = str(getattr(cat_obj, 'id', '') or '')

    monitorados = set(FORUM_CHANNEL_IDS)
    monitorados.update(CATEGORIA_IDS)

    # Checagem rápida ANTES de logar — silencia ruído de canais que não são
    # nossos (ex: #sala-resenha, #completa-apostado). Sem isso o log fica
    # poluído com dezenas de "canal não monitorado" por hora.
    canal_eh_monitorado = (ch_id in monitorados or parent_id in monitorados or cat_id in monitorados)
    if not canal_eh_monitorado:
        return

    # LOG SEMPRE que vir um 'pg' em canal monitorado — pra debug
    print(f"[{stamp()}] [PG] 🛎️ '{conteudo[:60]}' em #{getattr(message.channel, 'name', '?')} "
          f"(ch={ch_id}, parent={parent_id or '-'}, cat={cat_id or '-'}, monitorados={sorted(monitorados)})", flush=True)

    # Gate PIX_AUTO_ATIVO: precisa do canal ativado pela chave PIX. Sem isso
    # o bot ficaria respondendo PG em canais que nem tiveram venda iniciada.
    if not _canal_pode_agir(message):
        print(f"[{stamp()}] [PG] 🔒 #{getattr(message.channel, 'name', '?')} ainda não ativado (chave PIX não detectada). PIX_AUTO_ATIVO=True. Ignorando.", flush=True)
        return

    termos = [_norm(t) for t in consulta.split() if t.strip()]

    # ─── FALLBACK OCR: se pg veio SEM nome (só "pg") mas tem OCR fresco no canal,
    # usa nome+valor extraídos do comprovante. Permite o cliente mandar só "pg"
    # depois de postar a imagem.
    ocr_canal = _ocr_pegar_do_canal(ch_id)
    usou_ocr = False
    valor_ocr = None
    if (not termos or len(termos) < 2) and ocr_canal and ocr_canal.get('nome'):
        ocr_nome = ocr_canal['nome']
        termos = [_norm(p) for p in ocr_nome.split() if p.strip()]
        if len(termos) >= 2:
            consulta = ocr_nome
            valor_ocr = ocr_canal.get('valor')
            usou_ocr = True
            extra_val = f", valor R$ {valor_ocr:.2f}" if valor_ocr else ""
            print(f"[{stamp()}] [PG] 📸 Usando OCR do canal: '{ocr_nome}'{extra_val}", flush=True)

    if not termos:
        print(f"[{stamp()}] [PG] ⏭️ Sem termos pra buscar (sem nome digitado e sem OCR no canal).", flush=True)
        return

    # === MODO SILENCIOSO (1 palavra apenas) ===
    # Antes: 1 palavra abortava direto pra evitar falso positivo.
    # Agora: roda a busca em silêncio (sem mandar "verificando..."), e só responde
    # no chat SE achar exatamente 1 match. 0 ou 2+ matches → não fala nada
    # (pra cliente confirmar manualmente quando ambíguo).
    modo_silencioso = len(termos) < 2
    if modo_silencioso:
        print(f"[{stamp()}] [PG] 🤫 Só 1 palavra ('{consulta}') — modo silencioso. Vou responder só se achar exatamente 1 match.", flush=True)

    print(f"[{stamp()}] [PG] 🔎 Consulta de {message.author.name}: '{consulta}'{' (via OCR)' if usou_ocr else ''}", flush=True)

    # Pega valor mínimo. Prioridade: valor do OCR (mais específico) > valor capturado de bot.
    valor_minimo = valor_ocr if valor_ocr is not None else _valor_por_canal.get(ch_id)
    if valor_minimo is not None:
        origem_val = "do comprovante (OCR)" if valor_ocr is not None else "do canal (bot)"
        print(f"[{stamp()}] [PG] 💵 Valor mínimo: R$ {valor_minimo:.2f} ({origem_val}).", flush=True)
    else:
        print(f"[{stamp()}] [PG] ⚠️ Sem valor de referência — busca sem filtro de valor.", flush=True)

    # Se esse autor já teve uma busca automática disparada pelo OCR neste canal
    # (ele postou o comprovante e o bot já agiu), ignora o `pg` dele pra não
    # duplicar. Janela de 10min — se passou disso é provavelmente outro pagamento.
    if _ja_tem_comprovante_disparado(ch_id, message.author.id):
        print(f"[{stamp()}] [PG] ⏭️ @{message.author.name} já teve busca automática disparada via comprovante neste canal — ignorando 'pg'.", flush=True)
        return

    # Chama a função extraída — mesma lógica, agora também usada pelo OCR automático
    await _buscar_e_responder_pg(
        message=message,
        canal=message.channel,
        autor_id=message.author.id,
        autor_nome=message.author.name,
        consulta=consulta,
        termos=termos,
        valor_minimo=valor_minimo,
        modo_silencioso=modo_silencioso,
        ch_id=ch_id,
    )


# ═════════════════════════════════════════════════════════════
# Criação de sala com retry automático em caso de rate limit.
# Roda em background — segue tentando até criar com sucesso ou erro permanente.
# ═════════════════════════════════════════════════════════════
async def _criar_sala_com_retry(canal, modo, nome_sala, ch_id):
    """Tenta criar a sala via SalasBot API.

    NOVA lógica (com failover entre endpoints):
      1. Itera por SALAS_API_URLS (primária → fallback) em cada "rodada" de retry
      2. Pra cada URL, tenta 1× — se for erro retryable (BRIDGE_OFFLINE, 5xx,
         timeout, conexão), pula pra próxima URL imediatamente (sem espera)
      3. Se TODAS as URLs falharem com erro retryable, espera backoff (3s/6s/12s)
         e faz outra rodada
      4. Rate limit (429) continua sendo tratado SEPARADO — espera o retry_after
         informado e tenta de novo na mesma URL
      5. Erro permanente (AUTH/modo inválido) cai imediato sem retry

    Resultado: BRIDGE_OFFLINE numa URL agora dispara fallback automático pra outra,
    e se as duas estiverem down faz 3 rodadas com backoff antes de desistir.
    """
    # Quantas rodadas (cada rodada = tentar todas as URLs) com backoff entre elas.
    # 3 rodadas × 2 URLs = 6 tentativas, mais que suficiente pra contornar 
    # janela de instabilidade da SalasBot. Backoff: 3s, 6s, 12s.
    MAX_RODADAS_RETRYABLE = 3
    BACKOFFS = [3, 6, 12]
    # Pra rate-limit (rodada separada), ainda permitimos várias esperas
    MAX_RODADAS_RATE_LIMIT = 8
    avisou_espera = False

    # ─── Gate de SALDO ───
    # Se o configurador já reportou um saldo numérico e está <= 0, NÃO cria a sala.
    # NÃO avisa no chat do Discord — o aviso de "salas acabaram" aparece no
    # painel-cliente (site). Aqui só registra no log do bot pro admin ver.
    # Quando _saldo_salas é None significa "ainda não busquei" — libera (não
    # bloqueia o cliente caso o configurador esteja fora do ar momentaneamente).
    if _saldo_salas is not None and _saldo_salas <= 0:
        print(f"[{stamp()}] [SALDO] 🚫 Sem saldo de salas ({_saldo_salas}). "
              f"Não criando sala em #{nome_sala}. (Aviso aparece no painel-cliente.)", flush=True)
        # Libera trava do canal pra não travar pra sempre — quando recarregar saldo,
        # próximo pg dispara de novo se o saldo voltar.
        _sala_criada_canal.discard(ch_id)
        _pgs_confirmados_por_canal[ch_id] = 1
        return

    # Delay humanoide ANTES de chamar a API — entre 2 e 4s. Faz o bot parecer
    # estar "abrindo a sala" (igual humano clicaria) em vez de criar instantâneo.
    delay_humano = random.uniform(2.0, 4.0)
    print(f"[{stamp()}] [SALA] ⏱️ Delay humanoide de {delay_humano:.1f}s antes de chamar a API...", flush=True)
    await asyncio.sleep(delay_humano)

    rodadas_retryable = 0
    rodadas_rate_limit = 0
    ultimo_erro = 'erro desconhecido'
    ultimo_tipo = 'OUTRO'

    while True:
        # Decide se ainda tem orçamento de tentativas
        if rodadas_retryable >= MAX_RODADAS_RETRYABLE and rodadas_rate_limit >= MAX_RODADAS_RATE_LIMIT:
            break

        # ─── Rodada: tenta CADA URL uma vez ───
        # Se uma URL der OK, sucesso. Se der retryable, anota e tenta a próxima.
        # Se der rate-limit, espera o retry_after pedido. Se der permanente, desiste.
        erro_retryable_na_rodada = False
        rate_limited_na_rodada = False
        rate_limit_wait = 0

        for i_url, base_url in enumerate(SALAS_API_URLS):
            label_url = base_url.split('//', 1)[-1]  # só host pra log mais limpo
            resultado = await _criar_sala_api(modo, nome_sala, base_url=base_url)

            if resultado.get('ok'):
                room_id = resultado.get('roomId', '?')
                senha_sala = resultado.get('senha', '') or '—'
                modo_criado = resultado.get('modoCriado', f'modo {modo}')
                sshash = resultado.get('sshash', '') or ''
                # base_url_usada: quem deu OK. Salva no cache pra _iniciar_sala_api
                # mandar o GO pra mesma URL (o sshash é específico do endpoint).
                base_url_ok = resultado.get('base_url_usada', base_url)
                print(f"[{stamp()}] [SALA] ✅ Sala criada via {label_url}: roomId={room_id}, senha={senha_sala}, modo={modo_criado}, sshash={sshash[:20] + '...' if sshash else '(vazio)'}", flush=True)

                # ─── Debita 1 saldo no configurador ───
                # Só rola se temos um saldo conhecido (não None). Fire-and-forget pra
                # não bloquear o pós-criação — se falhar, fica como erro de log; a
                # próxima _fetch_config_configurador (5min) corrige o estado local.
                if _saldo_salas is not None:
                    asyncio.create_task(_debitar_saldo_no_configurador())

                # Salva no cache do canal pra poder iniciar depois (quando 2 GOs aparecerem)
                _dados_sala_canal[ch_id] = {
                    'sshash': sshash,
                    'roomId': str(room_id),
                    'senha': str(senha_sala),
                    'modo': modo,
                    'base_url': base_url_ok,  # qual endpoint criou (usar mesmo no start)
                }

                # ─── RESET de estado de GO pra este canal ───
                # Importante quando o mesmo canal é reutilizado pra uma 2ª venda na mesma
                # execução do bot. Sem isso, _sala_iniciada_canal trava pra sempre e o
                # GO da 2ª venda NUNCA dispara. _gos_por_canal também precisa zerar pra
                # contagem (2 usuários únicos) começar do zero.
                tinha_iniciada = ch_id in _sala_iniciada_canal
                gos_antigos = len(_gos_por_canal.get(ch_id, set()))
                _sala_iniciada_canal.discard(ch_id)
                _gos_por_canal.pop(ch_id, None)
                if tinha_iniciada or gos_antigos:
                    print(f"[{stamp()}] [SALA] 🧹 #{nome_sala}: resetando estado de GO (sala_iniciada={tinha_iniciada}, gos_anteriores={gos_antigos}). Pronto pra próxima rodada.", flush=True)

                # FORMATO_SALA controla COMO o ID e a senha são enviados:
                #   - 'junto'    → 1 mensagem "ID SENHA" (ex: "123456789 22")
                #   - 'separado' → 2 mensagens (ID, depois SENHA)
                # Cliente configura no painel-cliente.
                try:
                    if FORMATO_SALA == 'junto':
                        # 1 msg só. Se não houver senha, manda só o ID.
                        if senha_sala:
                            await _humano_typing_send(canal, f"{room_id} {senha_sala}", min_delay=0.8, max_delay=1.8)
                        else:
                            await _humano_typing_send(canal, str(room_id), min_delay=0.8, max_delay=1.8)
                    else:
                        # 'separado' (default): ID em uma msg, senha em outra.
                        await _humano_typing_send(canal, str(room_id), min_delay=0.8, max_delay=1.8)
                        await asyncio.sleep(random.uniform(0.5, 1.2))
                        if senha_sala:
                            await _humano_typing_send(canal, str(senha_sala), min_delay=0.6, max_delay=1.4)

                    # Mensagem fixa pós-sala — explica pros players o fluxo do GO.
                    # 2 players mandando "go" no canal → bot chama API e inicia a sala.
                    await asyncio.sleep(random.uniform(0.5, 1.0))
                    caixa_go = _caixa_simples([
                        "🎮  **ENVIE `go` NO CHAT**",
                        "✅  Após 2 players, iniciarei",
                    ], largura=34)
                    await _humano_typing_send(canal, caixa_go, min_delay=0.8, max_delay=1.8)
                except Exception as e:
                    print(f"[{stamp()}] [SALA] ❌ Erro ao postar sala em #{nome_sala}: {e}", flush=True)
                return

            # Falhou nessa URL. Decide o que fazer.
            erro = resultado.get('msg_erro', 'erro desconhecido')
            ultimo_erro = erro

            if resultado.get('rate_limited'):
                # Rate limit é específico da KEY (não da URL) — tentar outra URL
                # vai dar igual. Quebra o loop de URLs e espera.
                rate_limited_na_rodada = True
                rate_limit_wait = int(resultado.get('retry_after', 30))
                rate_limit_wait = max(1, min(rate_limit_wait, 300))  # clamp 1-300s
                print(f"[{stamp()}] [SALA] ⏳ Rate limit em {label_url}. Espera {rate_limit_wait}s antes de tentar de novo.", flush=True)
                break  # sai do for de URLs, processa lá embaixo

            if resultado.get('retryable'):
                # Erro transitório (BRIDGE_OFFLINE, 5xx, timeout, conexão).
                # Tenta a próxima URL IMEDIATAMENTE (sem espera).
                erro_retryable_na_rodada = True
                ultimo_tipo = _classificar_erro_sala(erro)
                resta = len(SALAS_API_URLS) - (i_url + 1)
                if resta > 0:
                    print(f"[{stamp()}] [SALA] ⚠️ {label_url} retryable ({ultimo_tipo}): {erro[:80]}. Tentando próximo endpoint...", flush=True)
                else:
                    print(f"[{stamp()}] [SALA] ⚠️ {label_url} retryable ({ultimo_tipo}): {erro[:80]}. Todos os endpoints falharam nesta rodada.", flush=True)
                continue  # próxima URL

            # Erro permanente (AUTH/modo inválido/etc) — desiste imediato
            _sala_criada_canal.discard(ch_id)
            _pgs_confirmados_por_canal[ch_id] = 1
            tipo_erro = _classificar_erro_sala(erro)
            print(f"[{stamp()}] [SALA] ❌ Falha permanente em {label_url} (tipo={tipo_erro}): {erro}", flush=True)
            asyncio.create_task(_reportar_erro_sala_no_configurador(tipo_erro, erro))
            return

        # ─── Pós-rodada: decide próxima ação ───
        if rate_limited_na_rodada:
            rodadas_rate_limit += 1
            if rodadas_rate_limit > MAX_RODADAS_RATE_LIMIT:
                break

            # Avisa o canal só uma vez pra não floodar
            if not avisou_espera:
                avisou_espera = True
                try:
                    await _humano_typing_send(canal, f"⏳ Aguarda um momento...", min_delay=0.4, max_delay=1.0)
                except Exception:
                    pass

            await asyncio.sleep(rate_limit_wait + 1)  # +1s de margem
            continue

        if erro_retryable_na_rodada:
            # Todas as URLs deram erro transitório. Backoff e tenta de novo.
            rodadas_retryable += 1
            if rodadas_retryable >= MAX_RODADAS_RETRYABLE:
                # Esgotou — desiste
                break
            espera = BACKOFFS[min(rodadas_retryable - 1, len(BACKOFFS) - 1)]
            print(f"[{stamp()}] [SALA] ⏳ Rodada {rodadas_retryable}/{MAX_RODADAS_RETRYABLE} esgotada (todos endpoints retryable). Backoff {espera}s antes da próxima rodada.", flush=True)
            await asyncio.sleep(espera)
            continue

        # Saiu do for sem ok, sem rate-limit, sem retryable, sem permanente — não deveria
        # acontecer, mas por segurança quebra.
        break

    # Esgotou todas as tentativas — libera trava e reporta
    _sala_criada_canal.discard(ch_id)
    _pgs_confirmados_por_canal[ch_id] = 1
    print(f"[{stamp()}] [SALA] ❌ Esgotou {MAX_RODADAS_RETRYABLE} rodadas × {len(SALAS_API_URLS)} endpoints. Último erro: {ultimo_erro}", flush=True)
    asyncio.create_task(_reportar_erro_sala_no_configurador(
        ultimo_tipo or 'OUTRO',
        f'Esgotou {MAX_RODADAS_RETRYABLE}x{len(SALAS_API_URLS)} tentativas. Último: {ultimo_erro}'
    ))
    try:
        await _humano_typing_send(
            canal,
            f"⚠️ A API da sala está instável agora ({ultimo_tipo}). Manda `pg` de novo em ~1min pra tentar.",
            min_delay=0.6, max_delay=1.5
        )
    except Exception:
        pass


@client.event
async def on_disconnect():
    print(f"[{stamp()}] 🔌 Desconectado, tentando reconectar...", flush=True)


# ════════════════════════════════════════════════════════════════════
# DIAGNÓSTICO DE TOKEN no startup
# Tokens de USUÁRIO podem ter qualquer prefixo (MT, NT, MD, OD, MM, etc).
# A primeira parte do token é o user_id codificado em base64 — como o user_id
# muda por conta, o prefixo muda também. NT é tão válido quanto MT.
# Aqui só logamos o formato pra ajudar a diagnosticar quando dá erro.
# ════════════════════════════════════════════════════════════════════
if DISCORD_TOKEN:
    _tk = DISCORD_TOKEN.strip()
    _partes = _tk.split('.')
    _prefixo = _tk[:2] if len(_tk) >= 2 else '?'
    _comprimento = len(_tk)
    _formato_ok = len(_partes) == 3 and 50 <= _comprimento <= 100
    print(f"[{stamp()}] 🔑 Token: prefixo='{_prefixo}', tamanho={_comprimento}, partes={len(_partes)}, formato={'✅ válido' if _formato_ok else '⚠️ suspeito'}", flush=True)
    if not _formato_ok:
        print(f"[{stamp()}] ⚠️  Token tem formato incomum. Tokens de usuário Discord têm 3 partes separadas por ponto (xxxxx.yyyyy.zzzzz) e ~70 caracteres. Confira se copiou completo.", flush=True)

# ════════════════════════════════════════════════════════════════════
# CAPTURA DE LOGS INTERNOS DO discord.py-self
# O `client.run()` engole vários erros (ConnectionClosed do gateway,
# CAPTCHA exigido no identify, etc) e só loga eles via logger interno
# do discord.py — sem print pro stdout. Esses erros ficam invisíveis na
# Discloud porque o handler default da lib só vai pra stderr/null.
#
# Aqui prendo TODOS os loggers do discord.* e mando pro nosso stdout,
# com level WARNING pra cima (DEBUG do gateway é spam). Assim qualquer
# crash que antes era silencioso aparece no log da Discloud.
# ════════════════════════════════════════════════════════════════════
_discord_log = logging.getLogger('discord')
_discord_log.setLevel(logging.WARNING)
_discord_handler = logging.StreamHandler(sys.stdout)
_discord_handler.setLevel(logging.WARNING)
_discord_handler.setFormatter(logging.Formatter('%(asctime)s [%(name)s:%(levelname)s] %(message)s', datefmt='%H:%M:%S'))
# Evita duplicar handler se o módulo for reimportado por algum motivo
if not any(isinstance(h, logging.StreamHandler) and getattr(h, '_selfbot_marker', False) for h in _discord_log.handlers):
    _discord_handler._selfbot_marker = True
    _discord_log.addHandler(_discord_handler)


def _idle_forever(motivo):
    """Trava o processo em loop infinito de sleep com log periódico.

    Por que: o `AUTORESTART=true` no discloud.config faz a Discloud reiniciar
    o processo a cada crash. Pra erros de auth/CAPTCHA isso é PÉSSIMO porque:
      - Cada restart = novo login no Discord
      - Login consecutivo do mesmo IP = Cloudflare ban (code 1015)
      - Cloudflare ban no IP da Discloud = todos os outros selfbots ficam ruins

    Idle no lugar de morrer mantém o processo "vivo" pro Discloud não
    reiniciar, e dá ao admin tempo de corrigir (trocar token, esperar
    CAPTCHA passar, etc) sem martelar a API do Discord.
    """
    print(f"[{stamp()}] 🛑 Entrando em IDLE infinito — motivo: {motivo}", flush=True)
    print(f"[{stamp()}] 💡 Pra retomar: corrige o problema acima, depois reinicia o app na Discloud manualmente.", flush=True)
    import time as _t
    ciclo = 0
    while True:
        ciclo += 1
        # Log a cada 5min pra mostrar que o processo tá vivo sem floodar.
        # Sleep em pedaços de 60s pra responder a SIGTERM mais rápido se a
        # Discloud mandar stop.
        for _ in range(5):
            _t.sleep(60)
        print(f"[{stamp()}] 💤 IDLE ciclo #{ciclo} ({ciclo * 5}min em idle). Motivo: {motivo}", flush=True)


def _explicar_captcha():
    print(f"[{stamp()}] 🔎 CAPTCHA exigido pelo Discord. Acontece quando:", flush=True)
    print(f"[{stamp()}]    1) Conta loga de IP novo (Discloud) sem ter logado antes desse IP", flush=True)
    print(f"[{stamp()}]    2) Conta foi flagada como suspeita por comportamento de selfbot", flush=True)
    print(f"[{stamp()}]    3) Discord rotou políticas e exige verificação nova", flush=True)
    print(f"[{stamp()}] 💡 Como resolver:", flush=True)
    print(f"[{stamp()}]    a) Abre discord.com no navegador NO MESMO PC que tem 2FA da conta", flush=True)
    print(f"[{stamp()}]    b) Loga normal, resolve qualquer CAPTCHA que aparecer", flush=True)
    print(f"[{stamp()}]    c) Pega token NOVO (F12 → Network → header 'authorization')", flush=True)
    print(f"[{stamp()}]    d) Atualiza DISCORD_TOKEN no configurador → Aplicar Variáveis", flush=True)


async def _rodar_bot():
    """Wrapper async em volta do client.start() pra capturar exceptions que
    o client.run() (sync) engole silenciosamente. ConnectionClosed do gateway,
    CAPTCHA no identify, e GatewayNotFound só aparecem se a gente rodar
    no event loop manualmente."""
    print(f"[{stamp()}] 🔌 Iniciando client.start() — conectando ao Discord...", flush=True)

    # Task heartbeat: imprime ALIVE a cada 30s pra você saber que o bot tá vivo
    # mesmo quando não está processando mensagens. NÃO bloqueia o client.start
    # — é só pra log. Para quando client.start acaba.
    _hb_alive = True
    async def _heartbeat():
        n = 0
        while _hb_alive:
            await asyncio.sleep(30)
            n += 1
            if not _hb_alive: break
            estado = 'CONECTADO' if client.is_ready() else 'CONECTANDO'
            print(f"[{stamp()}] 💓 ALIVE {n*30}s · estado={estado}", flush=True)
    _hb_task = asyncio.create_task(_heartbeat())

    try:
        # client.start() é uma corrotina LONGA — fica rodando ENQUANTO o bot está
        # conectado. Só retorna quando o bot desconecta de vez (login falha, ou
        # gateway fecha permanentemente). NÃO envelopar em wait_for(timeout=X)
        # porque isso mata o bot depois de X segundos mesmo conectado.
        await client.start(DISCORD_TOKEN)
        _hb_alive = False
        try: _hb_task.cancel()
        except Exception: pass
        # Se chegou aqui SEM exception, o client encerrou normalmente.
        print(f"[{stamp()}] ⚠️ client.start() retornou sem exception. is_ready={client.is_ready()}, is_closed={client.is_closed()}", flush=True)
        if not client.is_ready():
            print(f"[{stamp()}] 🛑 client.start() saiu sem conectar — sem exception. Possível CAPTCHA silencioso ou bug.", flush=True)
            _idle_forever("client.start() saiu silenciosamente")
            return
    except discord.LoginFailure as e:
        print(f"[{stamp()}] ❌ LOGIN FALHOU: {e}", flush=True)
        print(f"[{stamp()}] 🔎 Causas comuns:", flush=True)
        print(f"[{stamp()}]    1) Token copiado errado ou incompleto", flush=True)
        print(f"[{stamp()}]    2) Conta deslogada em outro dispositivo (token invalidou)", flush=True)
        print(f"[{stamp()}]    3) Conta banida/disabled pelo Discord", flush=True)
        print(f"[{stamp()}]    4) Discord forçou rotação de token — pega de novo no DevTools", flush=True)
        print(f"[{stamp()}] 💡 Pra pegar token novo: abre discord.com no navegador → F12 → Network → manda qualquer msg → procura header 'authorization'.", flush=True)
        _idle_forever("LOGIN FALHOU (token invalido/revogado)")
    except discord.HTTPException as e:
        code = getattr(e, 'status', None) or getattr(e, 'code', None)
        texto = str(e).lower()
        # Detecta CAPTCHA pelo conteúdo da resposta (Discord retorna
        # 'captcha_key' ou 'captcha_sitekey' no JSON do erro)
        if 'captcha' in texto:
            print(f"[{stamp()}] ❌ DISCORD EXIGIU CAPTCHA (HTTP {code}): {e}", flush=True)
            _explicar_captcha()
            _idle_forever("CAPTCHA exigido")
        else:
            print(f"[{stamp()}] ❌ ERRO HTTP DISCORD (code={code}): {e}", flush=True)
            if code == 429:
                print(f"[{stamp()}] 🔎 Rate limit no LOGIN. IP da Discloud tá quente — aguarda 15-30min.", flush=True)
                _idle_forever(f"Rate limit HTTP {code}")
            elif code in (400, 403):
                print(f"[{stamp()}] 🔎 Discord rejeitou a conexão. Provavelmente CAPTCHA implícito.", flush=True)
                _explicar_captcha()
                _idle_forever(f"HTTP {code} — Discord rejeitou")
            else:
                _idle_forever(f"HTTP {code} inesperado")
    except discord.ConnectionClosed as e:
        # Discord fechou o gateway. Code 4004 = token invalido, 4014 = intents
        # privilegiadas faltando (não aplica a selfbot), 4xxx em geral = motivo
        # permanente que reconectar não vai resolver.
        code = getattr(e, 'code', None)
        print(f"[{stamp()}] ❌ GATEWAY FECHOU (code={code}): {e}", flush=True)
        if code == 4004:
            print(f"[{stamp()}] 🔎 Code 4004 = TOKEN INVÁLIDO. Discord rejeitou no IDENTIFY.", flush=True)
            print(f"[{stamp()}] 💡 Token foi invalidado depois do login HTTP — comum quando Discord", flush=True)
            print(f"[{stamp()}]    pede CAPTCHA. Loga manualmente no navegador, pega token novo.", flush=True)
        elif code and 4000 <= code <= 4999:
            print(f"[{stamp()}] 🔎 Code {code} é permanente (não adianta reconectar).", flush=True)
        _idle_forever(f"Gateway code {code}")
    except Exception as e:
        print(f"[{stamp()}] ❌ ERRO FATAL ({type(e).__name__}): {e}", flush=True)
        import traceback
        print(f"[{stamp()}] Traceback:", flush=True)
        traceback.print_exc()
        sys.stdout.flush()
        _idle_forever(f"{type(e).__name__}: {str(e)[:80]}")
    finally:
        # Para o heartbeat task se ainda estiver rodando
        _hb_alive = False
        try:
            _hb_task.cancel()
        except Exception:
            pass
        # Garante que o client foi fechado direito antes de qualquer coisa
        try:
            if not client.is_closed():
                await client.close()
        except Exception:
            pass


print(f"[{stamp()}] 🚀 Entrando em asyncio.run(_rodar_bot)...", flush=True)
try:
    asyncio.run(_rodar_bot())
    # Se asyncio.run COMPLETOU normalmente, _rodar_bot retornou — quer dizer
    # que client.start() finalizou ou caímos no _idle_forever. Idle bloqueia
    # então só chegamos aqui se algo retornou silenciosamente. Não deixa o
    # processo morrer (que causa restart loop na Discloud).
    print(f"[{stamp()}] ⚠️ asyncio.run() RETORNOU SEM ERRO — _rodar_bot terminou. Entrando em idle pra evitar restart loop.", flush=True)
    _idle_forever("asyncio.run retornou silenciosamente")
except KeyboardInterrupt:
    # SIGTERM da Discloud (stop manual) — sai limpo, NÃO entra em idle
    print(f"[{stamp()}] 👋 Parado manualmente.", flush=True)
except SystemExit as e:
    # Algum código chamou sys.exit() — Discloud reinicia se a gente deixar.
    print(f"[{stamp()}] ⚠️ SystemExit interceptado (code={e.code}). Entrando em idle pra não restartar.", flush=True)
    _idle_forever(f"SystemExit code={e.code}")
except BaseException as e:
    # BaseException pega TUDO — Exception, GeneratorExit, etc. Sem isso,
    # certos crashes do asyncio (CancelledError, etc) escapam e o processo
    # morre, causando o crash loop que vimos no sup_riick_3.
    print(f"[{stamp()}] ❌ ERRO no asyncio.run ({type(e).__name__}): {e}", flush=True)
    import traceback
    traceback.print_exc()
    sys.stdout.flush()
    _idle_forever(f"asyncio: {type(e).__name__}: {str(e)[:80]}")
